package com.example.miautomotrizapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {

    EditText etEmail, etPassword;
    Button btnLogin;

    // Lista simulada de usuarios registrados
    ArrayList<Usuario> usuariosRegistrados = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);

        // Uuarios de ejemplo (simulados)
        usuariosRegistrados.add(new Usuario("adminMIAU@automotriz.cl", "1234"));
        usuariosRegistrados.add(new Usuario("clienteMIAU@automotriz.cl", "abcd"));

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString();
                String pass = etPassword.getText().toString();

                if (validarUsuario(email, pass)) {
                    // Si el usuario está registrado, entra al menú principal
                    Toast.makeText(LoginActivity.this, "Inicio de sesión exitoso", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();
                } else {
                    // Si no está registrado, muestra alerta
                    mostrarAlerta("Usuario no registrado", "El correo o la contraseña son incorrectos. Intente nuevamente o registre una cuenta.");
                }
            }
        });
    }

    private boolean validarUsuario(String email, String password) {
        for (Usuario u : usuariosRegistrados) {
            if (u.getEmail().equalsIgnoreCase(email) && u.getPassword().equals(password)) {
                return true;
            }
        }
        return false;
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        new AlertDialog.Builder(this)
                .setTitle(titulo)
                .setMessage(mensaje)
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                })
                .show();
    }
}
