package com.example.miautomotrizapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miautomotrizapp.db.AutomotrizDbHelper;

import java.util.List;

public class ServicioAdapter extends RecyclerView.Adapter<ServicioAdapter.ServicioViewHolder> {

    private Context context;
    private List<Servicio> listaServicios;
    private AutomotrizDbHelper dbHelper;

    public ServicioAdapter(Context context, List<Servicio> listaServicios) {
        this.context = context;
        this.listaServicios = listaServicios;
        this.dbHelper = new AutomotrizDbHelper(context);
    }

    @NonNull
    @Override
    public ServicioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_servicio, parent, false);
        return new ServicioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ServicioViewHolder holder, int position) {
        Servicio servicio = listaServicios.get(position);

        holder.tvNombre.setText(servicio.getNombre());
        holder.tvDescripcion.setText(servicio.getDescripcion());
        holder.tvPrecio.setText(servicio.getPrecio());
        holder.ivIcono.setImageResource(servicio.getImagen());

        // Clic en toda la fila (ir a Mecánico)
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, EscogerMecanicoActivity.class);
            intent.putExtra("nombreServicio", servicio.getNombre());
            intent.putExtra("precioServicio", servicio.getPrecio());
            context.startActivity(intent);
        });

        // --- 1. ACCIÓN DE CLIC PARA EL BOTÓN DE EDITAR ---
        holder.ivEditar.setOnClickListener(v -> {
            // Obtenemos el ID del servicio
            int idServicioParaEditar = servicio.getId();

            // Creamos el Intent para abrir la pantalla de Edición
            Intent intent = new Intent(context, EditarServicioActivity.class);
            // Le pasamos el ID usando la constante que definimos
            intent.putExtra(EditarServicioActivity.EXTRA_SERVICIO_ID, idServicioParaEditar);

            context.startActivity(intent);
        });

        // --- 2. ACCIÓN DE CLIC PARA EL BOTÓN DE ELIMINAR ---
        holder.ivEliminar.setOnClickListener(v -> {
            int idServicioParaEliminar = servicio.getId();
            int currentPosition = holder.getAdapterPosition();

            if (currentPosition != RecyclerView.NO_POSITION) {
                int filasEliminadas = dbHelper.eliminarServicio(idServicioParaEliminar);
                if (filasEliminadas > 0) {
                    listaServicios.remove(currentPosition);
                    notifyItemRemoved(currentPosition);
                    Toast.makeText(context, "Servicio eliminado", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Error al eliminar", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaServicios.size();
    }

    // Método para actualizar la lista
    public void actualizarLista(List<Servicio> nuevaLista) {
        this.listaServicios.clear();
        this.listaServicios.addAll(nuevaLista);
        this.notifyDataSetChanged();
    }

    // --- ViewHolder ---
    public static class ServicioViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre, tvDescripcion, tvPrecio;
        ImageView ivIcono;
        ImageView ivEliminar;
        ImageView ivEditar; // <-- 3. AÑADIMOS LA REFERENCIA AL ÍCONO DE EDITAR

        public ServicioViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvNombreServicio);
            tvDescripcion = itemView.findViewById(R.id.tvDescripcionServicio);
            tvPrecio = itemView.findViewById(R.id.tvPrecioServicio);
            ivIcono = itemView.findViewById(R.id.ivIconoServicio);
            ivEliminar = itemView.findViewById(R.id.ivEliminarServicio);
            ivEditar = itemView.findViewById(R.id.ivEditarServicio); // <-- 4. BUSCAMOS EL ID
        }
    }
}

