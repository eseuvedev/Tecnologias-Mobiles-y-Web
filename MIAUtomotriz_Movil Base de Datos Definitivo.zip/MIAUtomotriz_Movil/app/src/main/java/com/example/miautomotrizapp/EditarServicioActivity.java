package com.example.miautomotrizapp;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.miautomotrizapp.db.AutomotrizDbHelper;

public class EditarServicioActivity extends AppCompatActivity {

    // Constante para pasar el ID
    public static final String EXTRA_SERVICIO_ID = "EXTRA_SERVICIO_ID";

    // Vistas
    private EditText etNombre, etDescripcion, etPrecio;
    private Button btnGuardar;
    private TextView tvTitulo; // Para cambiar el título

    // Base de datos
    private AutomotrizDbHelper dbHelper;
    private Servicio servicioActual; // El servicio que estamos editando

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_servicio); // Usamos el layout copiado

        // 1. Inicializar vistas y DbHelper
        dbHelper = new AutomotrizDbHelper(this);
        etNombre = findViewById(R.id.etNombreServicio);
        etDescripcion = findViewById(R.id.etDescripcionServicio);
        etPrecio = findViewById(R.id.etPrecioServicio);
        btnGuardar = findViewById(R.id.btnGuardarServicio);

        // (Opcional) Cambiamos el título
        tvTitulo = findViewById(R.id.tvTituloFormulario); // Necesitarías añadir este ID al XML
        if (tvTitulo != null) {
            tvTitulo.setText("Editar Servicio");
        }
        btnGuardar.setText("Actualizar Servicio");

        // 2. Obtener el ID que nos pasó la lista
        int servicioId = getIntent().getIntExtra(EXTRA_SERVICIO_ID, -1);

        // 3. Validar el ID
        if (servicioId == -1) {
            Toast.makeText(this, "Error: ID de servicio no válido", Toast.LENGTH_SHORT).show();
            finish(); // Cerramos si no hay ID
            return;
        }

        // 4. Leer el servicio de la BD (usando el método que creamos)
        servicioActual = dbHelper.leerServicioPorId(servicioId);

        if (servicioActual == null) {
            Toast.makeText(this, "Error: Servicio no encontrado", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // 5. Rellenar el formulario con los datos actuales
        etNombre.setText(servicioActual.getNombre());
        etDescripcion.setText(servicioActual.getDescripcion());
        etPrecio.setText(servicioActual.getPrecio());

        // 6. Poner el listener al botón de guardar
        btnGuardar.setOnClickListener(v -> actualizarServicio());
    }

    private void actualizarServicio() {
        // 1. Obtener los nuevos textos de los EditText
        String nombre = etNombre.getText().toString().trim();
        String descripcion = etDescripcion.getText().toString().trim();
        String precio = etPrecio.getText().toString().trim();

        // 2. Validar que no estén vacíos
        if (nombre.isEmpty() || descripcion.isEmpty() || precio.isEmpty()) {
            Toast.makeText(this, "Por favor, llena todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        // 3. Crear un nuevo objeto Servicio con los datos actualizados
        //    Usamos la imagen que ya tenía, ya que no la estamos editando.
        Servicio servicioActualizado = new Servicio(
                nombre,
                descripcion,
                precio,
                servicioActual.getImagen() // Mantenemos la imagen original
        );

        // 4. ¡MUY IMPORTANTE! Asignarle el ID original
        servicioActualizado.setId(servicioActual.getId());

        // 5. Actualizar en la base de datos
        int filasAfectadas = dbHelper.actualizarServicio(servicioActualizado);

        if (filasAfectadas > 0) {
            Toast.makeText(this, "Servicio actualizado", Toast.LENGTH_SHORT).show();
            finish(); // Cerramos y volvemos a la lista
        } else {
            Toast.makeText(this, "Error al actualizar", Toast.LENGTH_SHORT).show();
        }
    }
}
