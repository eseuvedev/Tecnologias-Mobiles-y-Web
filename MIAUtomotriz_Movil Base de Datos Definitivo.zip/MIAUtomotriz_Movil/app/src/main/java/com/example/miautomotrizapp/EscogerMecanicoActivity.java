package com.example.miautomotrizapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Button;
import android.widget.Toast;
import android.content.SharedPreferences;
import android.widget.TextView;
import android.view.View;

public class EscogerMecanicoActivity extends AppCompatActivity {

    Spinner spinnerMecanicos;
    Button btnGuardar;
    TextView tvTituloServicio; // 🔹 para mostrar el servicio seleccionado

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escoger_mecanico);

        spinnerMecanicos = findViewById(R.id.spinnerMecanicos);
        btnGuardar = findViewById(R.id.btnGuardarMecanico);
        tvTituloServicio = findViewById(R.id.tvTituloServicio); // 👈 asegúrate de tener este TextView en tu layout

        // 🔹 Recibir datos del servicio seleccionado desde el RecyclerView
        String nombreServicio = getIntent().getStringExtra("nombreServicio");
        double precioServicio = getIntent().getDoubleExtra("precioServicio", 0);

        // 🔹 Mostrar el servicio actual en pantalla
        if (nombreServicio != null) {
            tvTituloServicio.setText("Elegir mecánico para: " + nombreServicio);
        } else {
            tvTituloServicio.setText("Elegir mecánico");
        }

        // 🔹 Lista de mecánicos
        String[] mecanicos = {"Carlos López", "Ana Pérez", "Luis Morales", "Javiera Soto", "Pedro González"};

        // 🔹 Adaptador para el Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, mecanicos);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerMecanicos.setAdapter(adapter);

        // 🔹 Acción al presionar "Guardar"
        btnGuardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mecanicoSeleccionado = spinnerMecanicos.getSelectedItem().toString();

                // Guardar en SharedPreferences
                SharedPreferences prefs = getSharedPreferences("DatosApp", MODE_PRIVATE);
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("mecanicoSeleccionado", mecanicoSeleccionado);
                editor.putString("servicioSeleccionado", nombreServicio); // 👈 guarda también el servicio
                editor.apply();

                Toast.makeText(EscogerMecanicoActivity.this,
                        "Servicio: " + nombreServicio + "\nMecánico: " + mecanicoSeleccionado,
                        Toast.LENGTH_SHORT).show();

                finish(); // Volver a la pantalla anterior
            }
        });
    }
}
