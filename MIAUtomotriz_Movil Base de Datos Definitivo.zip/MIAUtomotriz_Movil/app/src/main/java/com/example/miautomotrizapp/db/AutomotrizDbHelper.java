package com.example.miautomotrizapp.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

import com.example.miautomotrizapp.Servicio; // Importante

import java.util.ArrayList;
import java.util.List;

public class AutomotrizDbHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "automotriz.db";

    public static final String TABLE_SERVICIOS = "servicios";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NOMBRE = "nombre";
    public static final String COLUMN_DESCRIPCION = "descripcion";
    public static final String COLUMN_PRECIO = "precio";
    public static final String COLUMN_IMAGEN = "imagen";

    public AutomotrizDbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_SERVICIOS = "CREATE TABLE " + TABLE_SERVICIOS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NOMBRE + " TEXT,"
                + COLUMN_DESCRIPCION + " TEXT,"
                + COLUMN_PRECIO + " TEXT,"
                + COLUMN_IMAGEN + " INTEGER" + ")";

        db.execSQL(CREATE_TABLE_SERVICIOS);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SERVICIOS);
        onCreate(db);
    }

    public long insertarServicio(Servicio servicio) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NOMBRE, servicio.getNombre());
        values.put(COLUMN_DESCRIPCION, servicio.getDescripcion());
        values.put(COLUMN_PRECIO, servicio.getPrecio());
        values.put(COLUMN_IMAGEN, servicio.getImagen());

        long newRowId = db.insert(TABLE_SERVICIOS, null, values);
        db.close();
        return newRowId;
    }

    public List<Servicio> leerTodosLosServicios() {
        List<Servicio> listaServicios = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_SERVICIOS, null, null, null, null, null, null);

        int idIndex = cursor.getColumnIndex(COLUMN_ID);
        int nombreIndex = cursor.getColumnIndex(COLUMN_NOMBRE);
        int descIndex = cursor.getColumnIndex(COLUMN_DESCRIPCION);
        int precioIndex = cursor.getColumnIndex(COLUMN_PRECIO);
        int imagenIndex = cursor.getColumnIndex(COLUMN_IMAGEN);

        while (cursor.moveToNext()) {
            // Asegurarse que los índices son válidos
            if (idIndex != -1 && nombreIndex != -1 && descIndex != -1 && precioIndex != -1 && imagenIndex != -1) {
                int id = cursor.getInt(idIndex);
                String nombre = cursor.getString(nombreIndex);
                String descripcion = cursor.getString(descIndex);
                String precio = cursor.getString(precioIndex);
                int imagen = cursor.getInt(imagenIndex);

                Servicio servicio = new Servicio(nombre, descripcion, precio, imagen);
                servicio.setId(id);

                listaServicios.add(servicio);
            }
        }

        cursor.close();
        db.close();

        return listaServicios;
    }

    public int actualizarServicio(Servicio servicio) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NOMBRE, servicio.getNombre());
        values.put(COLUMN_DESCRIPCION, servicio.getDescripcion());
        values.put(COLUMN_PRECIO, servicio.getPrecio());
        values.put(COLUMN_IMAGEN, servicio.getImagen());

        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(servicio.getId()) };

        int count = db.update(
                TABLE_SERVICIOS,
                values,
                selection,
                selectionArgs);

        db.close();
        return count;
    }

    public int eliminarServicio(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        int deletedRows = db.delete(TABLE_SERVICIOS, selection, selectionArgs);

        db.close();
        return deletedRows;
    }

    public Servicio leerServicioPorId(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Definimos las columnas que queremos (null trae todas)
        String[] projection = {
                COLUMN_ID,
                COLUMN_NOMBRE,
                COLUMN_DESCRIPCION,
                COLUMN_PRECIO,
                COLUMN_IMAGEN
        };

        // Cláusula WHERE (seleccionar por ID)
        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        Cursor cursor = db.query(
                TABLE_SERVICIOS,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        Servicio servicio = null;

        // Si el cursor encontró algo, nos movemos a la primera (y única) fila
        if (cursor.moveToFirst()) {
            int idIndex = cursor.getColumnIndex(COLUMN_ID);
            int nombreIndex = cursor.getColumnIndex(COLUMN_NOMBRE);
            int descIndex = cursor.getColumnIndex(COLUMN_DESCRIPCION);
            int precioIndex = cursor.getColumnIndex(COLUMN_PRECIO);
            int imagenIndex = cursor.getColumnIndex(COLUMN_IMAGEN);

            String nombre = cursor.getString(nombreIndex);
            String descripcion = cursor.getString(descIndex);
            String precio = cursor.getString(precioIndex);
            int imagen = cursor.getInt(imagenIndex);

            servicio = new Servicio(nombre, descripcion, precio, imagen);
            servicio.setId(id); // Asignamos el ID
        }

        cursor.close();
        db.close();

        return servicio; // Devolvemos el servicio encontrado (o null)
    }

}
