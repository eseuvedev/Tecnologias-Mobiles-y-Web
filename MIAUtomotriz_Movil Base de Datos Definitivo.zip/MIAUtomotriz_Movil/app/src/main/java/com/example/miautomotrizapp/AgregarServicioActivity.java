package com.example.miautomotrizapp;

import com.example.miautomotrizapp.db.AutomotrizDbHelper;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// Importamos el DbHelper


public class AgregarServicioActivity extends AppCompatActivity {

    // Vistas
    private EditText etNombre, etDescripcion, etPrecio;
    private Button btnGuardar;

    // Base de datos
    private AutomotrizDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_servicio);

        // Inicializamos el DbHelper
        dbHelper = new AutomotrizDbHelper(this);

        // Enlazamos las vistas
        etNombre = findViewById(R.id.etNombreServicio);
        etDescripcion = findViewById(R.id.etDescripcionServicio);
        etPrecio = findViewById(R.id.etPrecioServicio);
        btnGuardar = findViewById(R.id.btnGuardarServicio);

        // Ponemos el listener al botón de guardar
        btnGuardar.setOnClickListener(v -> guardarServicio());
    }

    private void guardarServicio() {
        // 1. Obtenemos los textos de los EditText
        String nombre = etNombre.getText().toString().trim();
        String descripcion = etDescripcion.getText().toString().trim();
        String precio = etPrecio.getText().toString().trim();

        // 2. Validamos que no estén vacíos
        if (nombre.isEmpty() || descripcion.isEmpty() || precio.isEmpty()) {
            Toast.makeText(this, "Por favor, llena todos los campos", Toast.LENGTH_SHORT).show();
            return; // Detenemos la ejecución si algo falta
        }

        // 3. Creamos el nuevo objeto Servicio
        // Nota: Usamos una imagen por defecto (R.drawable.aceite)
        // Implementar un selector de imagen es mucho más complejo.
        int imagenPorDefecto = R.drawable.aceite; // O cualquier ícono que tengas
        Servicio nuevoServicio = new Servicio(nombre, descripcion, precio, imagenPorDefecto);

        // 4. Insertamos en la base de datos
        long id = dbHelper.insertarServicio(nuevoServicio);

        if (id != -1) {
            // Si el id no es -1, significa que se guardó correctamente
            Toast.makeText(this, "Servicio guardado", Toast.LENGTH_SHORT).show();
            // 5. Cerramos esta actividad y volvemos a la lista
            finish();
        } else {
            Toast.makeText(this, "Error al guardar el servicio", Toast.LENGTH_SHORT).show();
        }
    }
}