<?php
require "db.php";
session_start();

if (!isset($_SESSION["usuario"])) {
    header("Location: index.php");
    exit();
}

$rol = $_SESSION["rol"] ?? "mecanico";
$conn = conectarDB();

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, "UTF-8"); }

/* =========================================================
   POST: CRUD (solo admin)
   ========================================================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $accion = $_POST["accion"] ?? "";

    if ($rol !== "admin") {
        header("Location: inventario_repuestos.php");
        exit();
    }

    // -------- CREAR PIEZA --------
    if ($accion === "crear") {
        $codigo           = (int)($_POST["codigo"] ?? 0);
        $numeropieza      = ($_POST["numeropieza"] === "" ? null : (int)$_POST["numeropieza"]);
        $nombre           = trim($_POST["nombre"] ?? "");
        $categoria        = trim($_POST["categoria"] ?? "");
        $descripcion      = trim($_POST["descripcion"] ?? "");
        $ano              = ($_POST["ano"] === "" ? null : (int)$_POST["ano"]);
        $codigo_inventario= (int)($_POST["codigo_inventario"] ?? 0);

        $sql = "
            INSERT INTO pieza (codigo, numeropieza, nombre, categoria, descripcion, ano, codigo_inventario)
            VALUES ($1,$2,$3,$4,$5,$6,$7)
        ";
        @pg_query_params($conn, $sql, [
            $codigo, $numeropieza, $nombre, $categoria, $descripcion, $ano, $codigo_inventario
        ]);

        header("Location: inventario_repuestos.php");
        exit();
    }

    // -------- EDITAR PIEZA --------
    if ($accion === "editar") {
        $codigo           = (int)($_POST["codigo"] ?? 0);
        $numeropieza      = ($_POST["numeropieza"] === "" ? null : (int)$_POST["numeropieza"]);
        $nombre           = trim($_POST["nombre"] ?? "");
        $categoria        = trim($_POST["categoria"] ?? "");
        $descripcion      = trim($_POST["descripcion"] ?? "");
        $ano              = ($_POST["ano"] === "" ? null : (int)$_POST["ano"]);
        $codigo_inventario= (int)($_POST["codigo_inventario"] ?? 0);

        $sql = "
            UPDATE pieza
            SET numeropieza = $1,
                nombre = $2,
                categoria = $3,
                descripcion = $4,
                ano = $5,
                codigo_inventario = $6
            WHERE codigo = $7
        ";
        @pg_query_params($conn, $sql, [
            $numeropieza, $nombre, $categoria, $descripcion, $ano, $codigo_inventario, $codigo
        ]);

        header("Location: inventario_repuestos.php");
        exit();
    }

    // -------- ELIMINAR PIEZA --------
    if ($accion === "eliminar") {
        $codigo = (int)($_POST["codigo"] ?? 0);

        // Ojo: si está referenciada por otras tablas (ordenrequierepieza, etc.) puede fallar.
        $sql = "DELETE FROM pieza WHERE codigo = $1";
        @pg_query_params($conn, $sql, [$codigo]);

        header("Location: inventario_repuestos.php");
        exit();
    }

    header("Location: inventario_repuestos.php");
    exit();
}

/* =========================================================
   GET: listado + búsqueda
   ========================================================= */
$busqueda = trim($_GET["q"] ?? "");

if ($busqueda !== "") {
    $sql = "
        SELECT
            p.codigo,
            p.numeropieza,
            p.nombre,
            p.categoria,
            p.descripcion,
            p.ano,
            p.codigo_inventario,
            it.nombreequipo,
            it.ubicacion
        FROM pieza p
        JOIN inventariotaller it ON it.codigo_inventario = p.codigo_inventario
        WHERE p.codigo::text ILIKE $1
           OR COALESCE(p.nombre,'') ILIKE $1
           OR COALESCE(p.categoria,'') ILIKE $1
           OR COALESCE(p.descripcion,'') ILIKE $1
           OR COALESCE(it.nombreequipo,'') ILIKE $1
           OR COALESCE(it.ubicacion,'') ILIKE $1
        ORDER BY p.nombre ASC
    ";
    $result = pg_query_params($conn, $sql, ['%'.$busqueda.'%']);
} else {
    $sql = "
        SELECT
            p.codigo,
            p.numeropieza,
            p.nombre,
            p.categoria,
            p.descripcion,
            p.ano,
            p.codigo_inventario,
            it.nombreequipo,
            it.ubicacion
        FROM pieza p
        JOIN inventariotaller it ON it.codigo_inventario = p.codigo_inventario
        ORDER BY p.nombre ASC
    ";
    $result = pg_query($conn, $sql);
}

if (!$result) {
    die("Error al ejecutar la consulta de repuestos.");
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Inventario (Repuestos) — MIAUtomotriz</title>
  <link rel="stylesheet" href="./static/css/styles.css" />
  <style>
    .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);padding:1rem;z-index:9999;}
    .modal.is-open{display:flex;align-items:center;justify-content:center;}
    .modal .box{background:#fff;border-radius:12px;max-width:760px;width:100%;padding:1rem;}
    .row{display:flex;gap:.75rem;flex-wrap:wrap}
    .row > div{flex:1;min-width:220px}
    .actions{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center}
    .btn{padding:.35rem .6rem;border:1px solid #999;border-radius:8px;background:#f7f7f7;cursor:pointer;text-decoration:none;color:#000}
    .btn.danger{border-color:#b00020}
    input, textarea{width:100%}
    table{width:100%;border-collapse:collapse}
    th,td{border-bottom:1px solid #ddd;padding:.5rem;text-align:left;vertical-align:top}
    .toolbar{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center}
  </style>
</head>

<body class="app-<?= h($rol) ?>">
<header>
  <a class="brand" href="dashboard.php" aria-label="Ir al dashboard">
  <img src="/static/img/logo.png" alt="MIAUtomotriz">
  </a>

  <h1>MIAUtomotriz</h1>
  <p class="tagline">Inventario — Repuestos</p>
  <nav aria-label="principal">
    <ul>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="index.php">Salir</a></li>
    </ul>
  </nav>
</header>

<main class="wide">
  <section>
    <h2>Repuestos (tabla pieza)</h2>

    <form method="get" class="toolbar">
      <label for="q">Buscar:</label>
      <input id="q" name="q" placeholder="Código, nombre, categoría, inventario, ubicación..." value="<?= h($busqueda) ?>" style="max-width:360px;">
      <button class="btn" type="submit">Buscar</button>

      <?php if ($busqueda !== ""): ?>
        <a class="btn" href="inventario_repuestos.php">Limpiar</a>
      <?php endif; ?>

      <?php if ($rol === "admin"): ?>
        <button class="btn" type="button" onclick="openModal('modalCrear')">+ Nuevo repuesto</button>
      <?php endif; ?>
    </form>

    <div style="overflow:auto;margin-top:1rem;">
      <table>
        <thead>
          <tr>
            <th>Código</th>
            <th>N° pieza</th>
            <th>Nombre</th>
            <th>Categoría</th>
            <th>Descripción</th>
            <th>Año</th>
            <th>Inventario</th>
            <th>Ubicación</th>
            <?php if ($rol === "admin"): ?>
              <th>Acciones</th>
            <?php endif; ?>
          </tr>
        </thead>

        <tbody>
          <?php while ($row = pg_fetch_assoc($result)): ?>
            <tr>
              <td><?= h($row["codigo"]) ?></td>
              <td><?= h($row["numeropieza"] ?? "") ?></td>
              <td><?= h($row["nombre"]) ?></td>
              <td><?= h($row["categoria"] ?? "") ?></td>
              <td><?= h($row["descripcion"] ?? "") ?></td>
              <td><?= h($row["ano"] ?? "") ?></td>
              <td><?= h($row["nombreequipo"] ?? "") ?> (<?= h($row["codigo_inventario"]) ?>)</td>
              <td><?= h($row["ubicacion"] ?? "") ?></td>

              <?php if ($rol === "admin"): ?>
                <td class="actions">
                  <button class="btn" type="button"
                    onclick='openEditar(<?= json_encode($row, JSON_UNESCAPED_UNICODE) ?>)'>
                    Editar
                  </button>

                  <button class="btn danger" type="button"
                    onclick='openEliminar(<?= (int)$row["codigo"] ?>)'>
                    Eliminar
                  </button>
                </td>
              <?php endif; ?>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <?php if ($rol !== "admin"): ?>
      <p style="margin-top:.75rem;"><em>Modo Mecánico: solo lectura.</em></p>
    <?php endif; ?>
  </section>
</main>

<!-- ===================== MODALES (solo admin) ===================== -->

<div class="modal" id="modalCrear" role="dialog" aria-modal="true" aria-labelledby="tCrear">
  <div class="box">
    <h3 id="tCrear">Crear repuesto</h3>
    <form method="post">
      <input type="hidden" name="accion" value="crear">

      <div class="row">
        <div>
          <label>Código (PK)</label>
          <input type="number" name="codigo" min="1" required>
        </div>
        <div>
          <label>N° pieza</label>
          <input type="number" name="numeropieza" min="0">
        </div>
      </div>

      <div class="row">
        <div>
          <label>Nombre</label>
          <input name="nombre" required>
        </div>
        <div>
          <label>Categoría</label>
          <input name="categoria">
        </div>
      </div>

      <div class="row">
        <div>
          <label>Descripción</label>
          <textarea name="descripcion" rows="3"></textarea>
        </div>
      </div>

      <div class="row">
        <div>
          <label>Año</label>
          <input type="number" name="ano" min="1900" max="2100">
        </div>
        <div>
          <label>Código inventario (FK inventariotaller)</label>
          <input type="number" name="codigo_inventario" min="1" required>
        </div>
      </div>

      <div class="actions" style="margin-top:1rem;">
        <button class="btn" type="submit">Crear</button>
        <button class="btn" type="button" onclick="closeModal('modalCrear')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<div class="modal" id="modalEditar" role="dialog" aria-modal="true" aria-labelledby="tEditar">
  <div class="box">
    <h3 id="tEditar">Editar repuesto</h3>
    <form method="post">
      <input type="hidden" name="accion" value="editar">

      <div class="row">
        <div>
          <label>Código (no editable)</label>
          <input type="number" name="codigo" id="e_codigo" readonly>
        </div>
        <div>
          <label>N° pieza</label>
          <input type="number" name="numeropieza" id="e_numeropieza" min="0">
        </div>
      </div>

      <div class="row">
        <div>
          <label>Nombre</label>
          <input name="nombre" id="e_nombre" required>
        </div>
        <div>
          <label>Categoría</label>
          <input name="categoria" id="e_categoria">
        </div>
      </div>

      <div class="row">
        <div>
          <label>Descripción</label>
          <textarea name="descripcion" id="e_descripcion" rows="3"></textarea>
        </div>
      </div>

      <div class="row">
        <div>
          <label>Año</label>
          <input type="number" name="ano" id="e_ano" min="1900" max="2100">
        </div>
        <div>
          <label>Código inventario (FK)</label>
          <input type="number" name="codigo_inventario" id="e_codigo_inventario" min="1" required>
        </div>
      </div>

      <div class="actions" style="margin-top:1rem;">
        <button class="btn" type="submit">Guardar</button>
        <button class="btn" type="button" onclick="closeModal('modalEditar')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<div class="modal" id="modalEliminar" role="dialog" aria-modal="true" aria-labelledby="tEliminar">
  <div class="box">
    <h3 id="tEliminar">Eliminar repuesto</h3>
    <p>¿Seguro que deseas eliminar este repuesto?</p>
    <form method="post">
      <input type="hidden" name="accion" value="eliminar">
      <input type="hidden" name="codigo" id="d_codigo">
      <div class="actions" style="margin-top:1rem;">
        <button class="btn danger" type="submit">Eliminar</button>
        <button class="btn" type="button" onclick="closeModal('modalEliminar')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<script>
function openModal(id){ document.getElementById(id).classList.add("is-open"); }
function closeModal(id){ document.getElementById(id).classList.remove("is-open"); }

document.querySelectorAll(".modal").forEach(m=>{
  m.addEventListener("click", (e)=>{ if(e.target === m) m.classList.remove("is-open"); });
});

function openEditar(p){
  document.getElementById("e_codigo").value = p.codigo ?? "";
  document.getElementById("e_numeropieza").value = p.numeropieza ?? "";
  document.getElementById("e_nombre").value = p.nombre ?? "";
  document.getElementById("e_categoria").value = p.categoria ?? "";
  document.getElementById("e_descripcion").value = p.descripcion ?? "";
  document.getElementById("e_ano").value = p.ano ?? "";
  document.getElementById("e_codigo_inventario").value = p.codigo_inventario ?? "";
  openModal("modalEditar");
}

function openEliminar(codigo){
  document.getElementById("d_codigo").value = codigo;
  openModal("modalEliminar");
}
</script>

<footer>
  <small>MIAUtomotriz — Universidad de Los Lagos — 2025</small>
</footer>
</body>
</html>
