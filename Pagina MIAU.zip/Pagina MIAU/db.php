<?php
function conectarDB() {
    $host = "localhost";      // O IP del Raspberry
    $port = "5432";
    $dbname = "BASESUPREMA";
    $user = "postgres";
    $password = "chao123";

    $conexion = pg_connect("host=$host port=$port dbname=$dbname user=$user password=$password");

    if (!$conexion) {
        die("❌ Error de conexión con la base de datos.");
    }
    return $conexion;   //   cd "C:\Users\acer\Desktop\Pagina MIAU"
                        //   php -S localhost:8000
}
?>


 