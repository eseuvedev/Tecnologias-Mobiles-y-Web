<?php
require "db.php";
session_start();

if (!isset($_SESSION["usuario"])) {
    header("Location: index.php");
    exit();
}

$rol = $_SESSION["rol"] ?? "mecanico";
$conn = conectarDB();

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, "UTF-8"); }

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $accion = $_POST["accion"] ?? "";

    /* ---------- CREAR OT (solo admin) ---------- */
    if ($accion === "crear") {
        if ($rol !== "admin") { header("Location: ordenes_trabajo.php"); exit(); }

        $numero_orden   = (int)($_POST["numero_orden"] ?? 0);
        $fecha          = $_POST["fecha"] ?? null;
        $run            = trim($_POST["run"] ?? "");
        $patente        = trim($_POST["patente"] ?? "");
        $codigo_factura = (int)($_POST["codigo_factura"] ?? 0);

        $sql = "
            INSERT INTO ordendetrabajo (numero_orden, fecha, run, patente, codigo_factura, id_detalleorden)
            VALUES ($1, $2, $3, $4, $5, NULL)
        ";
        @pg_query_params($conn, $sql, [$numero_orden, $fecha, $run, $patente, $codigo_factura]);

        header("Location: ordenes_trabajo.php");
        exit();
    }

    /* ---------- EDITAR DETALLEORDEN  ---------- */
    if ($accion === "editar") {
        $numero_orden = (int)($_POST["numero_orden"] ?? 0);

        $kilometraje = ($_POST["kilometraje"] === "" ? null : (int)$_POST["kilometraje"]);
        $combustible = ($_POST["combustible"] === "" ? null : (int)$_POST["combustible"]);
        $repuestos   = ($_POST["repuestos"] === "" ? null : (int)$_POST["repuestos"]);

        $sqlGet = "SELECT id_detalleorden FROM ordendetrabajo WHERE numero_orden = $1";
        $resGet = pg_query_params($conn, $sqlGet, [$numero_orden]);
        $rowGet = $resGet ? pg_fetch_assoc($resGet) : null;

        if (!$rowGet) {
            header("Location: ordenes_trabajo.php");
            exit();
        }

        $id_detalleorden = $rowGet["id_detalleorden"];

        if ($id_detalleorden === null || $id_detalleorden === "") {

            $sqlNewId = "SELECT COALESCE(MAX(id_detalleorden),0) + 1 AS nuevo FROM detalleorden";
            $resNewId = pg_query($conn, $sqlNewId);
            $nuevoId  = (int)pg_fetch_assoc($resNewId)["nuevo"];

            $ins = "
                INSERT INTO detalleorden
                (id_detalleorden, totalrepuestos, combustibledisponible, kilometraje, cantidad, descuento, preciounitario, total)
                VALUES ($1, COALESCE($2,0), COALESCE($3,0), COALESCE($4,0), 0, 0, 0, 0)
            ";
            pg_query_params($conn, $ins, [$nuevoId, $repuestos, $combustible, $kilometraje]);

            $updOt = "UPDATE ordendetrabajo SET id_detalleorden = $1 WHERE numero_orden = $2";
            pg_query_params($conn, $updOt, [$nuevoId, $numero_orden]);

            $id_detalleorden = $nuevoId;
        }

        $updDet = "
            UPDATE detalleorden
            SET kilometraje = COALESCE($1, kilometraje),
                combustibledisponible = COALESCE($2, combustibledisponible),
                totalrepuestos = COALESCE($3, totalrepuestos)
            WHERE id_detalleorden = $4
        ";
        pg_query_params($conn, $updDet, [$kilometraje, $combustible, $repuestos, (int)$id_detalleorden]);

        header("Location: ordenes_trabajo.php");
        exit();
    }

    /* ---------- ELIMINAR OT (solo admin) ---------- */
    if ($accion === "eliminar") {
        if ($rol !== "admin") { header("Location: ordenes_trabajo.php"); exit(); }

        $numero_orden = (int)($_POST["numero_orden"] ?? 0);

        $del = "DELETE FROM ordendetrabajo WHERE numero_orden = $1";
        @pg_query_params($conn, $del, [$numero_orden]);

        header("Location: ordenes_trabajo.php");
        exit();
    }

    /* ===== AGREGAR REPUESTO A OT (ADMIN + MECANICO) ===== */
    if ($accion === "agregar_repuesto") {

        $numero_orden  = (int)($_POST["numero_orden"] ?? 0);
        $codigo_pieza  = (int)($_POST["codigo_pieza"] ?? 0);
        $montocompra   = (int)($_POST["montocompra"] ?? 0);
        $id_compra     = (int)($_POST["id_compra"] ?? 0);

        $sql = "
            INSERT INTO ordenrequierepieza (codigo_pieza, numero_orden, montocompra, id_compra)
            VALUES ($1, $2, $3, $4)
        ";
        @pg_query_params($conn, $sql, [$codigo_pieza, $numero_orden, $montocompra, $id_compra]);

        header("Location: ordenes_trabajo.php");
        exit();
    }
}

/* =========================================================
   GET: listado + búsqueda
   ========================================================= */
$busqueda = trim($_GET["q"] ?? "");

if ($busqueda !== "") {
    $sqlList = "
        SELECT
            ot.numero_orden,
            ot.fecha,
            ot.run,
            c.nombre AS cliente_nombre,
            c.apellido AS cliente_apellido,
            ot.patente,
            ot.codigo_factura,
            ot.id_detalleorden,
            d.kilometraje,
            d.combustibledisponible,
            d.totalrepuestos
        FROM ordendetrabajo ot
        JOIN cliente c ON c.run = ot.run
        LEFT JOIN detalleorden d ON d.id_detalleorden = ot.id_detalleorden
        WHERE ot.numero_orden::text ILIKE $1
           OR ot.run ILIKE $1
           OR ot.patente ILIKE $1
        ORDER BY ot.numero_orden DESC
    ";
    $result = pg_query_params($conn, $sqlList, ['%'.$busqueda.'%']);
} else {
    $sqlList = "
        SELECT
            ot.numero_orden,
            ot.fecha,
            ot.run,
            c.nombre AS cliente_nombre,
            c.apellido AS cliente_apellido,
            ot.patente,
            ot.codigo_factura,
            ot.id_detalleorden,
            d.kilometraje,
            d.combustibledisponible,
            d.totalrepuestos
        FROM ordendetrabajo ot
        JOIN cliente c ON c.run = ot.run
        LEFT JOIN detalleorden d ON d.id_detalleorden = ot.id_detalleorden
        ORDER BY ot.numero_orden DESC
    ";
    $result = pg_query($conn, $sqlList);
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Órdenes de Trabajo — MIAUtomotriz</title>
  <link rel="stylesheet" href="./static/css/styles.css" />
  <style>
    .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);padding:1rem;z-index:9999;}
    .modal.is-open{display:flex;align-items:center;justify-content:center;}
    .modal .box{background:#fff;border-radius:12px;max-width:560px;width:100%;padding:1rem;}
    .row{display:flex;gap:.75rem;flex-wrap:wrap}
    .row > div{flex:1;min-width:180px}
    .actions{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center}
    .btn{padding:.35rem .6rem;border:1px solid #999;border-radius:8px;background:#f7f7f7;cursor:pointer;text-decoration:none;color:#000}
    .btn.danger{border-color:#b00020}
    input{width:100%}
    table{width:100%;border-collapse:collapse}
    th,td{border-bottom:1px solid #ddd;padding:.5rem;text-align:left}
  </style>
</head>

<body class="app-<?= h($rol) ?>">
<header>
  <a class="brand" href="dashboard.php" aria-label="Ir al dashboard">
  <img src="/static/img/logo.png" alt="MIAUtomotriz">
  </a>

  <h1>MIAUtomotriz</h1>
  <p class="tagline">Órdenes de Trabajo</p>
  <nav aria-label="principal">
    <ul>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="index.php">Salir</a></li>
    </ul>
  </nav>
</header>

<main class="wide">
  <section>
    <h2>Listado de Órdenes</h2>

    <form method="get" class="search-form" style="display:flex;gap:.5rem;flex-wrap:wrap;align-items:center;">
      <label for="q">Buscar:</label>
      <input id="q" name="q" placeholder="N° orden, RUN o patente" value="<?= h($busqueda) ?>" style="max-width:320px;">
      <button class="btn" type="submit">Buscar</button>
      <?php if ($busqueda !== ""): ?>
        <a class="btn" href="ordenes_trabajo.php">Limpiar</a>
      <?php endif; ?>

      <?php if ($rol === "admin"): ?>
        <button class="btn" type="button" onclick="openModal('modalCrear')">+ Nueva OT</button>
      <?php endif; ?>
    </form>

    <div style="overflow:auto;margin-top:1rem;">
      <table>
        <thead>
          <tr>
            <th>N°</th>
            <th>Fecha</th>
            <th>Cliente</th>
            <th>RUN</th>
            <th>Patente</th>
            <th>Factura</th>
            <th>Km</th>
            <th>Comb %</th>
            <th>Repuestos</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          <?php while ($o = pg_fetch_assoc($result)): ?>
            <tr>
              <td><?= h($o["numero_orden"]) ?></td>
              <td><?= h($o["fecha"]) ?></td>
              <td><?= h($o["cliente_nombre"]." ".$o["cliente_apellido"]) ?></td>
              <td><?= h($o["run"]) ?></td>
              <td><?= h($o["patente"]) ?></td>
              <td><?= h($o["codigo_factura"]) ?></td>
              <td><?= h($o["kilometraje"] ?? "") ?></td>
              <td><?= h($o["combustibledisponible"] ?? "") ?></td>
              <td><?= h($o["totalrepuestos"] ?? "") ?></td>

              <td class="actions">
                <!-- PDF OT -->
                <a class="btn"
                   href="export_pdf.php?doc=ot&numero_orden=<?= (int)$o['numero_orden'] ?>"
                   target="_blank">
                  PDF OT
                </a>

                <!-- PDF FACTURA/BOLETA  -->
                <?php if (!empty($o["codigo_factura"])): ?>
                  <a class="btn"
                     href="export_pdf.php?doc=factura&codigo_factura=<?= (int)$o["codigo_factura"] ?>"
                     target="_blank">
                    PDF Factura
                  </a>
                <?php endif; ?>

                <button class="btn" type="button"
                  onclick='openEditar(<?= json_encode($o, JSON_UNESCAPED_UNICODE) ?>)'>
                  Editar
                </button>

                <?php if ($rol === "admin"): ?>
                  <button class="btn danger" type="button"
                    onclick='openEliminar(<?= (int)$o["numero_orden"] ?>)'>
                    Eliminar
                  </button>
                <?php endif; ?>
              </td>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>
  </section>
</main>

<!-- ===================== MODALES ===================== -->

<div class="modal" id="modalCrear" role="dialog" aria-modal="true" aria-labelledby="tCrear">
  <div class="box">
    <h3 id="tCrear">Crear Orden de Trabajo</h3>
    <form method="post">
      <input type="hidden" name="accion" value="crear">
      <div class="row">
        <div>
          <label>N° Orden</label>
          <input type="number" name="numero_orden" required>
        </div>
        <div>
          <label>Fecha</label>
          <input type="date" name="fecha" required>
        </div>
      </div>
      <div class="row">
        <div>
          <label>RUN Cliente</label>
          <input name="run" required placeholder="Ej: 12345678-9">
        </div>
        <div>
          <label>Patente</label>
          <input name="patente" required maxlength="6" placeholder="Ej: AB1234">
        </div>
      </div>
      <div class="row">
        <div>
          <label>Código Factura</label>
          <input type="number" name="codigo_factura" required>
        </div>
      </div>

      <div class="actions" style="margin-top:1rem;">
        <button class="btn" type="submit">Crear</button>
        <button class="btn" type="button" onclick="closeModal('modalCrear')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<div class="modal" id="modalEditar" role="dialog" aria-modal="true" aria-labelledby="tEditar">
  <div class="box">
    <h3 id="tEditar">Editar Detalle de OT</h3>
    <form method="post">
      <input type="hidden" name="accion" value="editar">
      <input type="hidden" name="numero_orden" id="e_numero_orden">

      <p style="margin:.25rem 0 .75rem;">
        OT: <strong id="e_ot_label"></strong> — Patente: <strong id="e_patente_label"></strong>
      </p>

      <div class="row">
        <div>
          <label>Kilometraje</label>
          <input type="number" name="kilometraje" id="e_kilometraje" min="0" placeholder="0">
        </div>
        <div>
          <label>Combustible disponible (%)</label>
          <input type="number" name="combustible" id="e_combustible" min="0" max="100" placeholder="0-100">
        </div>
      </div>
      <div class="row">
        <div>
          <label>Total repuestos</label>
          <input type="number" name="repuestos" id="e_repuestos" min="0" placeholder="0">
        </div>
      </div>

      <div class="actions" style="margin-top:1rem;">
        <button class="btn" type="submit">Guardar</button>
        <button class="btn" type="button" onclick="closeModal('modalEditar')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<div class="modal" id="modalEliminar" role="dialog" aria-modal="true" aria-labelledby="tEliminar">
  <div class="box">
    <h3 id="tEliminar">Eliminar OT</h3>
    <p>¿Seguro que deseas eliminar esta Orden de Trabajo?</p>
    <form method="post">
      <input type="hidden" name="accion" value="eliminar">
      <input type="hidden" name="numero_orden" id="d_numero_orden">

      <div class="actions" style="margin-top:1rem;">
        <button class="btn danger" type="submit">Eliminar</button>
        <button class="btn" type="button" onclick="closeModal('modalEliminar')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<script>
function openModal(id){ document.getElementById(id).classList.add("is-open"); }
function closeModal(id){ document.getElementById(id).classList.remove("is-open"); }

document.querySelectorAll(".modal").forEach(m=>{
  m.addEventListener("click", (e)=>{ if(e.target === m) m.classList.remove("is-open"); });
});

function openEditar(o){
  document.getElementById("e_numero_orden").value = o.numero_orden;
  document.getElementById("e_ot_label").textContent = o.numero_orden;
  document.getElementById("e_patente_label").textContent = o.patente || "";

  document.getElementById("e_kilometraje").value = o.kilometraje ?? "";
  document.getElementById("e_combustible").value = o.combustibledisponible ?? "";
  document.getElementById("e_repuestos").value = o.totalrepuestos ?? "";

  openModal("modalEditar");
}

function openEliminar(numero){
  document.getElementById("d_numero_orden").value = numero;
  openModal("modalEliminar");
}
</script>

</body>
</html>


