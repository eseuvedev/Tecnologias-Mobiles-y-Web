<?php
require "db.php";
session_start();

if (!isset($_SESSION["usuario"])) {
    header("Location: index.php");
    exit();
}

$rol = $_SESSION["rol"] ?? "mecanico";
$conn = conectarDB();

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, "UTF-8"); }

/* =========================================================
   POST: crear / editar / eliminar (según rol)
   ========================================================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $accion = $_POST["accion"] ?? "";

    // -------- CREAR (solo admin) --------
    if ($accion === "crear") {
        if ($rol !== "admin") { header("Location: lista_clientes.php"); exit(); }

        $run            = trim($_POST["run"] ?? "");
        $nombre         = trim($_POST["nombre"] ?? "");
        $apellido       = trim($_POST["apellido"] ?? "");
        $fechanac       = $_POST["fechanacimiento"] ?? null;
        $id_telefono    = (int)($_POST["id_telefono"] ?? 0);
        $id_giro        = (int)($_POST["id_giro"] ?? 0);
        $id_direccion   = (int)($_POST["id_direccion"] ?? 0);
        $id_email       = (int)($_POST["id_email"] ?? 0);

        $sql = "
            INSERT INTO cliente
            (run, nombre, apellido, fechanacimiento, id_telefono, id_giro, id_direccion, id_email)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
        ";
        @pg_query_params($conn, $sql, [
            $run, $nombre, $apellido, $fechanac,
            $id_telefono, $id_giro, $id_direccion, $id_email
        ]);

        header("Location: lista_clientes.php");
        exit();
    }

    // -------- EDITAR (solo admin) --------
    if ($accion === "editar") {
        if ($rol !== "admin") { header("Location: lista_clientes.php"); exit(); }

        $run            = trim($_POST["run"] ?? ""); // PK (no la cambiamos, solo la usamos para el WHERE)
        $nombre         = trim($_POST["nombre"] ?? "");
        $apellido       = trim($_POST["apellido"] ?? "");
        $fechanac       = $_POST["fechanacimiento"] ?? null;
        $id_telefono    = (int)($_POST["id_telefono"] ?? 0);
        $id_giro        = (int)($_POST["id_giro"] ?? 0);
        $id_direccion   = (int)($_POST["id_direccion"] ?? 0);
        $id_email       = (int)($_POST["id_email"] ?? 0);

        $sql = "
            UPDATE cliente
            SET nombre = $1,
                apellido = $2,
                fechanacimiento = $3,
                id_telefono = $4,
                id_giro = $5,
                id_direccion = $6,
                id_email = $7
            WHERE run = $8
        ";
        @pg_query_params($conn, $sql, [
            $nombre, $apellido, $fechanac,
            $id_telefono, $id_giro, $id_direccion, $id_email,
            $run
        ]);

        header("Location: lista_clientes.php");
        exit();
    }

    // -------- ELIMINAR (solo admin) --------
    if ($accion === "eliminar") {
        if ($rol !== "admin") { header("Location: lista_clientes.php"); exit(); }

        $run = trim($_POST["run"] ?? "");

        $sql = "DELETE FROM cliente WHERE run = $1";
        @pg_query_params($conn, $sql, [$run]);

        header("Location: lista_clientes.php");
        exit();
    }

    header("Location: lista_clientes.php");
    exit();
}

/* =========================================================
   GET: listado + búsqueda
   ========================================================= */
$busqueda = $_GET["q"] ?? "";

if ($busqueda !== "") {
    $sql = "
        SELECT *
        FROM cliente
        WHERE run ILIKE $1
           OR nombre ILIKE $1
           OR apellido ILIKE $1
        ORDER BY apellido ASC
    ";
    $result = pg_query_params($conn, $sql, ['%'.$busqueda.'%']);
} else {
    $sql = "SELECT * FROM cliente ORDER BY apellido ASC";
    $result = pg_query($conn, $sql);
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Lista de Clientes — MIAUtomotriz</title>
  <link rel="stylesheet" href="./static/css/styles.css" />

  <style>
    /* modal simple (si ya tienes, puedes borrar esto) */
    .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);padding:1rem;z-index:9999;}
    .modal.is-open{display:flex;align-items:center;justify-content:center;}
    .modal .box{background:#fff;border-radius:12px;max-width:640px;width:100%;padding:1rem;}
    .row{display:flex;gap:.75rem;flex-wrap:wrap}
    .row > div{flex:1;min-width:200px}
    .actions{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center}
    .btn{padding:.35rem .6rem;border:1px solid #999;border-radius:8px;background:#f7f7f7;cursor:pointer;text-decoration:none;color:#000}
    .btn.danger{border-color:#b00020}
    input{width:100%}
    table{width:100%;border-collapse:collapse}
    th,td{border-bottom:1px solid #ddd;padding:.5rem;text-align:left}
    .toolbar{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center}
  </style>
</head>

<body class="app-<?= h($rol) ?>">
<header>
  <a class="brand" href="dashboard.php" aria-label="Ir al dashboard">
  <img src="/static/img/logo.png" alt="MIAUtomotriz">
  </a>

  <h1>Lista de Clientes</h1>
  <nav aria-label="principal">
    <ul>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="index.php">Salir</a></li>
    </ul>
  </nav>
</header>

<main>
  <section aria-labelledby="clientes-table">
    <h2 id="clientes-table">Clientes registrados</h2>

    <form method="get" class="toolbar">
      <label for="q">Buscar:</label>
      <input id="q" name="q" placeholder="RUN, nombre o apellido" value="<?= h($busqueda) ?>" style="max-width:320px;">
      <button class="btn" type="submit">Buscar</button>

      <?php if ($busqueda !== ""): ?>
        <a class="btn" href="lista_clientes.php">Limpiar</a>
      <?php endif; ?>

      <?php if ($rol === "admin"): ?>
        <button class="btn" type="button" onclick="openModal('modalCrear')">+ Nuevo Cliente</button>
      <?php endif; ?>
    </form>

    <div style="overflow:auto;margin-top:1rem;">
      <table>
        <thead>
          <tr>
            <th>RUN</th>
            <th>Nombre</th>
            <th>Apellido</th>
            <th>Fecha Nac</th>
            <th>ID Tel</th>
            <th>ID Giro</th>
            <th>ID Dir</th>
            <th>ID Email</th>

            <?php if ($rol === "admin"): ?>
              <th>Acciones</th>
            <?php endif; ?>
          </tr>
        </thead>

        <tbody>
          <?php while ($row = pg_fetch_assoc($result)): ?>
            <tr>
              <td><?= h($row["run"]) ?></td>
              <td><?= h($row["nombre"]) ?></td>
              <td><?= h($row["apellido"]) ?></td>
              <td><?= h($row["fechanacimiento"]) ?></td>
              <td><?= h($row["id_telefono"]) ?></td>
              <td><?= h($row["id_giro"]) ?></td>
              <td><?= h($row["id_direccion"]) ?></td>
              <td><?= h($row["id_email"]) ?></td>

              <?php if ($rol === "admin"): ?>
                <td class="actions">
                  <button class="btn" type="button"
                    onclick='openEditar(<?= json_encode($row, JSON_UNESCAPED_UNICODE) ?>)'>
                    Editar
                  </button>

                  <button class="btn danger" type="button"
                    onclick='openEliminar(<?= json_encode($row["run"], JSON_UNESCAPED_UNICODE) ?>)'>
                    Eliminar
                  </button>
                </td>
              <?php endif; ?>
            </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <?php if ($rol !== "admin"): ?>
      <p style="margin-top:.75rem;"><em>Modo Mecánico: solo lectura.</em></p>
    <?php endif; ?>
  </section>
</main>

<!-- ===================== MODALES ===================== -->

<!-- CREAR -->
<div class="modal" id="modalCrear" role="dialog" aria-modal="true" aria-labelledby="tCrear">
  <div class="box">
    <h3 id="tCrear">Crear Cliente</h3>
    <form method="post">
      <input type="hidden" name="accion" value="crear">

      <div class="row">
        <div>
          <label>RUN</label>
          <input name="run" required placeholder="12345678-9">
        </div>
        <div>
          <label>Fecha nacimiento</label>
          <input type="date" name="fechanacimiento" required>
        </div>
      </div>

      <div class="row">
        <div>
          <label>Nombre</label>
          <input name="nombre" required>
        </div>
        <div>
          <label>Apellido</label>
          <input name="apellido" required>
        </div>
      </div>

      <div class="row">
        <div>
          <label>ID Teléfono (FK)</label>
          <input type="number" name="id_telefono" min="1" required>
        </div>
        <div>
          <label>ID Giro (FK)</label>
          <input type="number" name="id_giro" min="1" required>
        </div>
      </div>

      <div class="row">
        <div>
          <label>ID Dirección (FK)</label>
          <input type="number" name="id_direccion" min="1" required>
        </div>
        <div>
          <label>ID Email (FK)</label>
          <input type="number" name="id_email" min="1" required>
        </div>
      </div>

      <div class="actions" style="margin-top:1rem;">
        <button class="btn" type="submit">Crear</button>
        <button class="btn" type="button" onclick="closeModal('modalCrear')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<!-- EDITAR -->
<div class="modal" id="modalEditar" role="dialog" aria-modal="true" aria-labelledby="tEditar">
  <div class="box">
    <h3 id="tEditar">Editar Cliente</h3>
    <form method="post">
      <input type="hidden" name="accion" value="editar">

      <div class="row">
        <div>
          <label>RUN (no editable)</label>
          <input name="run" id="e_run" readonly>
        </div>
        <div>
          <label>Fecha nacimiento</label>
          <input type="date" name="fechanacimiento" id="e_fechanacimiento" required>
        </div>
      </div>

      <div class="row">
        <div>
          <label>Nombre</label>
          <input name="nombre" id="e_nombre" required>
        </div>
        <div>
          <label>Apellido</label>
          <input name="apellido" id="e_apellido" required>
        </div>
      </div>

      <div class="row">
        <div>
          <label>ID Teléfono (FK)</label>
          <input type="number" name="id_telefono" id="e_id_telefono" min="1" required>
        </div>
        <div>
          <label>ID Giro (FK)</label>
          <input type="number" name="id_giro" id="e_id_giro" min="1" required>
        </div>
      </div>

      <div class="row">
        <div>
          <label>ID Dirección (FK)</label>
          <input type="number" name="id_direccion" id="e_id_direccion" min="1" required>
        </div>
        <div>
          <label>ID Email (FK)</label>
          <input type="number" name="id_email" id="e_id_email" min="1" required>
        </div>
      </div>

      <div class="actions" style="margin-top:1rem;">
        <button class="btn" type="submit">Guardar</button>
        <button class="btn" type="button" onclick="closeModal('modalEditar')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<!-- ELIMINAR -->
<div class="modal" id="modalEliminar" role="dialog" aria-modal="true" aria-labelledby="tEliminar">
  <div class="box">
    <h3 id="tEliminar">Eliminar Cliente</h3>
    <p>¿Seguro que deseas eliminar este cliente?</p>
    <form method="post">
      <input type="hidden" name="accion" value="eliminar">
      <input type="hidden" name="run" id="d_run">

      <div class="actions" style="margin-top:1rem;">
        <button class="btn danger" type="submit">Eliminar</button>
        <button class="btn" type="button" onclick="closeModal('modalEliminar')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<script>
function openModal(id){ document.getElementById(id).classList.add("is-open"); }
function closeModal(id){ document.getElementById(id).classList.remove("is-open"); }

document.querySelectorAll(".modal").forEach(m=>{
  m.addEventListener("click", (e)=>{ if(e.target === m) m.classList.remove("is-open"); });
});

function openEditar(c){
  document.getElementById("e_run").value = c.run ?? "";
  document.getElementById("e_nombre").value = c.nombre ?? "";
  document.getElementById("e_apellido").value = c.apellido ?? "";
  document.getElementById("e_fechanacimiento").value = (c.fechanacimiento ?? "").substring(0,10);

  document.getElementById("e_id_telefono").value = c.id_telefono ?? "";
  document.getElementById("e_id_giro").value = c.id_giro ?? "";
  document.getElementById("e_id_direccion").value = c.id_direccion ?? "";
  document.getElementById("e_id_email").value = c.id_email ?? "";

  openModal("modalEditar");
}

function openEliminar(run){
  document.getElementById("d_run").value = run;
  openModal("modalEliminar");
}
</script>

</body>
</html>

