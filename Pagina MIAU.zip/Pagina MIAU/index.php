<?php
require "db.php";
session_start();

/**
 * Rol visual del login:
 * - admin    → paleta azul / gris
 * - mecanico → paleta verde / naranjo
 */
$rolVisual = $_GET['rol'] ?? 'admin';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $usuario    = $_POST["username"] ?? '';
    $password   = $_POST["password"] ?? '';
    $rolVisual  = $_POST["rol_visual"] ?? $rolVisual; // para mantener el modo visual tras el POST

    $conn = conectarDB();

    // Usamos la tabla sistema_usuario, SIN tocar tu modelo original
    $query  = "SELECT * FROM sistema_usuario WHERE email = $1 AND password = $2";
    $result = pg_query_params($conn, $query, [$usuario, $password]);

    if ($result && pg_num_rows($result) === 1) {
        $user = pg_fetch_assoc($result);

        $_SESSION["usuario"] = $user["email"];
        $_SESSION["rol"]     = $user["rol"]; // 'admin' o 'mecanico'

        header("Location: dashboard.php");
        exit();
    } else {
        $error = "Credenciales incorrectas";
    }
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>MIAUtomotriz — Login</title>
  <link rel="stylesheet" href="./static/css/styles.css" />
</head>
<body class="login-<?= htmlspecialchars($rolVisual) ?>">
  <header>
    <a class="brand" href="dashboard.php" aria-label="Ir al dashboard">
  <img src="/static/img/logo.png" alt="MIAUtomotriz">
  </a>

    <h1>MIAUtomotriz</h1>
    <p class="tagline">Sistema de gestión — Taller MIAUtomotriz</p>
  </header>

  <main>
    <section aria-labelledby="login-title">
      <h2 id="login-title">Iniciar sesión</h2>
      <article>

        <!-- Selector visual de rol -->
        <div class="role-switch">
          <a href="index.php?rol=admin"
             class="<?= ($rolVisual === 'admin') ? 'active-role' : '' ?>">
             Administrador
          </a>

          <a href="index.php?rol=mecanico"
             class="<?= ($rolVisual === 'mecanico') ? 'active-role' : '' ?>">
             Mecánico
          </a>
        </div>

        <?php if (!empty($error)): ?>
          <p class="login-error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <form method="post" action="index.php" autocomplete="on">
          <input type="hidden" name="rol_visual" value="<?= htmlspecialchars($rolVisual) ?>">

          <p id="login-help">Ingresa tus credenciales para acceder al panel.</p>

          <label for="username">Correo</label>
          <input id="username" name="username" type="text"
                 placeholder="ej: user@dominio.com" required />

          <label for="password">Contraseña</label>
          <input id="password" name="password" type="password"
                 placeholder="*******" required />

          <fieldset>
            <legend>Opciones</legend>
            <label>
              <input type="checkbox" name="remember" value="1" /> Recordarme
            </label>
          </fieldset>

          <button type="submit">Entrar</button>
        </form>

      </article>
    </section>
  </main>

  <footer>
    <small>MIAUtomotriz — Universidad de Los Lagos — 2025</small>
  </footer>
</body>
</html>


