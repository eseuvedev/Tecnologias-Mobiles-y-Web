<?php
session_start();

if (!isset($_SESSION["usuario"])) {
    header("Location: index.php");
    exit();
}

$rol = $_SESSION["rol"] ?? 'mecanico';
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>MIAUtomotriz — Dashboard</title>
  <link rel="stylesheet" href="./static/css/styles.css" />
</head>
<body class="app-<?= htmlspecialchars($rol) ?>">
  <header>
    <a class="brand" href="dashboard.php" aria-label="Ir al dashboard">
  <img src="/static/img/logo.png" alt="MIAUtomotriz">
  </a>

    <h1>MIAUtomotriz</h1>
    <p class="tagline">Panel principal — Taller Automotriz</p>
    <nav aria-label="principal">
      <ul>
        <li><a href="index.php">Salir</a></li>
      </ul>
    </nav>
  </header>

  <main>
    <section aria-labelledby="bienvenida">
      <h2 id="bienvenida">Bienvenido al sistema MIAUtomotriz</h2>
      <p>
        Usuario: <strong><?= htmlspecialchars($_SESSION["usuario"]) ?></strong><br>
        Rol: <strong><?= htmlspecialchars($rol) ?></strong>
      </p>
    </section>

    <?php if ($rol === 'admin'): ?>
      <!-- PANEL ADMINISTRADOR -->
      <section aria-labelledby="admin-section">
        <h3 id="admin-section">Panel del Administrador</h3>
        <p>Desde aquí el Administrador puede gestionar la información general del taller.</p>
        <ul>
          <li><a href="lista_clientes.php">Ver y gestionar clientes</a></li>
          <li><a href="ordenes_trabajo.php">Ordenes asignadas</a></li>
          <li><a href="lista_vehiculos.php">Lista de vehículos</a></li>
          <li><a href="inventario_repuestos.php">Inventario</a></li>
          <li><a href="cotizaciones.php">Cotizaciones</a></li>
          <li><a href="dashboard_estadistic.php">Estadisticas</a></li>
        </ul>
      </section>
    <?php endif; ?>

    <?php if ($rol === 'mecanico'): ?>
      <!-- PANEL MECÁNICO -->
      <section aria-labelledby="mecanico-section">
        <h3 id="mecanico-section">Panel del Mecánico</h3>
        <p>Desde aquí el Mecánico puede consultar y actualizar sus tareas asignadas.</p>
        <ul>
          <li><a href="lista_clientes.php">Ver clientes</a></li>
          <li><a href="ordenes_trabajo.php">Órdenes asignadas</a></li>
          <li><a href="lista_vehiculos.php">Lista de vehículos</a></li>
          <li><a href="inventario_repuestos.php">Inventario</a></li>
          <li><a href="cotizaciones.php">Cotizaciones</a></li>
        </ul>
      </section>
    <?php endif; ?>

  </main>

  <footer>
    <small>MIAUtomotriz — Universidad de Los Lagos — 2025</small>
  </footer>
</body>
</html>


