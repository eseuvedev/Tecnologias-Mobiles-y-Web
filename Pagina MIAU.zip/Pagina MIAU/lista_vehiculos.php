<?php
require "db.php";
session_start();

if (!isset($_SESSION["usuario"])) {
    header("Location: index.php");
    exit();
}

$rol = $_SESSION["rol"] ?? "mecanico";
$conn = conectarDB();

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, "UTF-8"); }

/* =========================================================
   POST: crear / editar / eliminar (según rol)
   ========================================================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $accion = $_POST["accion"] ?? "";

    /* ---------- CREAR (solo admin) ---------- */
    if ($accion === "crear") {
        if ($rol !== "admin") { header("Location: lista_vehiculos.php"); exit(); }

        $patente = strtoupper(trim($_POST["patente"] ?? ""));
        $run     = trim($_POST["run"] ?? "");

        $transmision = trim($_POST["transmision"] ?? "");
        $cilindrada  = ($_POST["cilindrada"] === "" ? null : (int)$_POST["cilindrada"]);
        $color       = trim($_POST["color"] ?? "");
        $motor       = trim($_POST["motor"] ?? "");

        // insertar vehiculo
        $sqlV = "
            INSERT INTO vehiculo (patente, transmision, cilindrada, color, motor, run, id_detallevehiculo)
            VALUES ($1,$2,$3,$4,$5,$6,$7)
        ";

        // id_detallevehiculo es FK NOT NULL. Como tu tabla detallevehiculo tiene PK INTEGER sin SERIAL,
        // generamos uno nuevo (max + 1) y creamos el registro.
        $resNew = pg_query($conn, "SELECT COALESCE(MAX(id_detallevehiculo),0)+1 AS nuevo FROM detallevehiculo");
        $nuevoDetalle = (int)pg_fetch_assoc($resNew)["nuevo"];

        // crear detallevehiculo base
        pg_query_params($conn, "INSERT INTO detallevehiculo (id_detallevehiculo, chasis, vin) VALUES ($1, NULL, NULL)", [$nuevoDetalle]);

        // ahora el vehiculo
        @pg_query_params($conn, $sqlV, [$patente, $transmision, $cilindrada, $color, $motor, $run, $nuevoDetalle]);

        // asignar marca (opcional) vía marcafabricamodelo
        $id_marca = ($_POST["id_marca"] === "" ? null : (int)$_POST["id_marca"]);
        if ($id_marca) {
            @pg_query_params(
                $conn,
                "INSERT INTO marcafabricamodelo (id_marca, patente) VALUES ($1,$2)",
                [$id_marca, $patente]
            );
        }

        header("Location: lista_vehiculos.php");
        exit();
    }

    /* ---------- EDITAR (admin + mecánico) ---------- */
    if ($accion === "editar") {
        $patente = strtoupper(trim($_POST["patente"] ?? ""));
        if ($patente === "") { header("Location: lista_vehiculos.php"); exit(); }

        // Mecánico puede actualizar datos técnicos del vehículo.
        // Admin puede además cambiar RUN (dueño) y marca.
        $transmision = trim($_POST["transmision"] ?? "");
        $cilindrada  = ($_POST["cilindrada"] === "" ? null : (int)$_POST["cilindrada"]);
        $color       = trim($_POST["color"] ?? "");
        $motor       = trim($_POST["motor"] ?? "");

        if ($rol === "admin") {
            $run = trim($_POST["run"] ?? "");

            $sql = "
                UPDATE vehiculo
                SET transmision = $1,
                    cilindrada = $2,
                    color = $3,
                    motor = $4,
                    run = $5
                WHERE patente = $6
            ";
            @pg_query_params($conn, $sql, [$transmision, $cilindrada, $color, $motor, $run, $patente]);

            // Marca (opcional) -> upsert en marcafabricamodelo
            $id_marca = ($_POST["id_marca"] === "" ? null : (int)$_POST["id_marca"]);
            if ($id_marca) {
                // si existe, actualiza; si no, inserta
                $chk = pg_query_params($conn, "SELECT 1 FROM marcafabricamodelo WHERE patente=$1", [$patente]);
                if (pg_num_rows($chk) > 0) {
                    @pg_query_params($conn, "UPDATE marcafabricamodelo SET id_marca=$1 WHERE patente=$2", [$id_marca, $patente]);
                } else {
                    @pg_query_params($conn, "INSERT INTO marcafabricamodelo (id_marca, patente) VALUES ($1,$2)", [$id_marca, $patente]);
                }
            }
        } else {
            // mecánico: NO cambia el dueño ni marca, solo técnica
            $sql = "
                UPDATE vehiculo
                SET transmision = $1,
                    cilindrada = $2,
                    color = $3,
                    motor = $4
                WHERE patente = $5
            ";
            @pg_query_params($conn, $sql, [$transmision, $cilindrada, $color, $motor, $patente]);
        }

        header("Location: lista_vehiculos.php");
        exit();
    }

    /* ---------- ELIMINAR (solo admin) ---------- */
    if ($accion === "eliminar") {
        if ($rol !== "admin") { header("Location: lista_vehiculos.php"); exit(); }

        $patente = strtoupper(trim($_POST["patente"] ?? ""));
        if ($patente === "") { header("Location: lista_vehiculos.php"); exit(); }

        // borrar relación marca si existe (por FK ON DELETE CASCADE desde vehiculo? aquí la tabla FK a vehiculo, así que
        // al borrar vehiculo debería borrar marcafabricamodelo por cascade, pero depende de cómo está FK; lo hacemos explícito igual)
        @pg_query_params($conn, "DELETE FROM marcafabricamodelo WHERE patente=$1", [$patente]);

        // obtener id_detallevehiculo para borrarlo después (si quieres mantenerlo, puedes omitir esto)
        $res = pg_query_params($conn, "SELECT id_detallevehiculo FROM vehiculo WHERE patente=$1", [$patente]);
        $row = pg_fetch_assoc($res);
        $id_det = $row ? (int)$row["id_detallevehiculo"] : null;

        // borrar vehiculo
        @pg_query_params($conn, "DELETE FROM vehiculo WHERE patente=$1", [$patente]);

        // borrar detallevehiculo asociado (si existe y quedó huérfano)
        if ($id_det) {
            @pg_query_params($conn, "DELETE FROM detallevehiculo WHERE id_detallevehiculo=$1", [$id_det]);
        }

        header("Location: lista_vehiculos.php");
        exit();
    }

    header("Location: lista_vehiculos.php");
    exit();
}

/* =========================================================
   GET: listado + búsqueda
   ========================================================= */
$busqueda = $_GET['q'] ?? '';

if ($busqueda !== '') {
    $sql = "
        SELECT
            v.patente,
            COALESCE(m.nombre, 'Sin marca') AS marca,
            m.id_marca,
            v.color,
            v.transmision,
            v.cilindrada,
            v.motor,
            c.run AS run_cliente,
            c.nombre AS nombre_cliente,
            c.apellido AS apellido_cliente
        FROM vehiculo v
        JOIN cliente c ON v.run = c.run
        LEFT JOIN marcafabricamodelo mfm ON v.patente = mfm.patente
        LEFT JOIN marca m ON mfm.id_marca = m.id_marca
        WHERE v.patente ILIKE $1
           OR COALESCE(m.nombre, '') ILIKE $1
           OR c.run ILIKE $1
           OR c.nombre ILIKE $1
           OR c.apellido ILIKE $1
        ORDER BY c.apellido ASC, v.patente ASC;
    ";
    $param = ['%' . $busqueda . '%'];
    $result = pg_query_params($conn, $sql, $param);
} else {
    $sql = "
        SELECT
            v.patente,
            COALESCE(m.nombre, 'Sin marca') AS marca,
            m.id_marca,
            v.color,
            v.transmision,
            v.cilindrada,
            v.motor,
            c.run AS run_cliente,
            c.nombre AS nombre_cliente,
            c.apellido AS apellido_cliente
        FROM vehiculo v
        JOIN cliente c ON v.run = c.run
        LEFT JOIN marcafabricamodelo mfm ON v.patente = mfm.patente
        LEFT JOIN marca m ON mfm.id_marca = m.id_marca
        ORDER BY c.apellido ASC, v.patente ASC;
    ";
    $result = pg_query($conn, $sql);
}

if (!$result) {
    die("Error al ejecutar la consulta de vehículos.");
}
?>

<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Lista de Vehículos — MIAUtomotriz</title>
  <link rel="stylesheet" href="./static/css/styles.css" />
  <style>
    .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);padding:1rem;z-index:9999;}
    .modal.is-open{display:flex;align-items:center;justify-content:center;}
    .modal .box{background:#fff;border-radius:12px;max-width:680px;width:100%;padding:1rem;}
    .row{display:flex;gap:.75rem;flex-wrap:wrap}
    .row > div{flex:1;min-width:200px}
    .actions{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center}
    .btn{padding:.35rem .6rem;border:1px solid #999;border-radius:8px;background:#f7f7f7;cursor:pointer;text-decoration:none;color:#000}
    .btn.danger{border-color:#b00020}
    input{width:100%}
    table{width:100%;border-collapse:collapse}
    th,td{border-bottom:1px solid #ddd;padding:.5rem;text-align:left}
    .toolbar{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center}
  </style>
</head>

<body class="app-<?= h($rol) ?>">
<header>
  <a class="brand" href="dashboard.php" aria-label="Ir al dashboard">
  <img src="/static/img/logo.png" alt="MIAUtomotriz">
  </a>

  <h1>MIAUtomotriz</h1>
  <p class="tagline">Lista de Vehículos</p>
  <nav aria-label="principal">
    <ul>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="index.php">Salir</a></li>
    </ul>
  </nav>
</header>

<main class="wide">
  <section aria-labelledby="titulo-vehiculos">
    <h2 id="titulo-vehiculos">Vehículos registrados en el sistema</h2>

    <form method="get" class="toolbar">
      <label for="q">Buscar:</label>
      <input id="q" name="q" placeholder="Patente, marca o cliente" value="<?= h($busqueda) ?>" style="max-width:320px;">
      <button class="btn" type="submit">Buscar</button>

      <?php if ($busqueda !== ''): ?>
        <a class="btn" href="lista_vehiculos.php">Limpiar</a>
      <?php endif; ?>

      <?php if ($rol === "admin"): ?>
        <button class="btn" type="button" onclick="openModal('modalCrear')">+ Nuevo Vehículo</button>
      <?php endif; ?>
    </form>

    <div style="overflow:auto;margin-top:1rem;">
    <table>
      <thead>
        <tr>
          <th>Patente</th>
          <th>Marca</th>
          <th>Color</th>
          <th>Transmisión</th>
          <th>Cilindrada</th>
          <th>Motor</th>
          <th>RUN Cliente</th>
          <th>Nombre Cliente</th>

          <?php if ($rol === "admin" || $rol === "mecanico"): ?>
            <th class="acciones">Acciones</th>
          <?php endif; ?>
        </tr>
      </thead>

      <tbody>
        <?php while ($row = pg_fetch_assoc($result)): ?>
          <tr>
            <td><?= h($row['patente']) ?></td>
            <td><?= h($row['marca']) ?></td>
            <td><?= h($row['color']) ?></td>
            <td><?= h($row['transmision']) ?></td>
            <td><?= h($row['cilindrada']) ?></td>
            <td><?= h($row['motor']) ?></td>
            <td><?= h($row['run_cliente']) ?></td>
            <td><?= h($row['nombre_cliente'] . ' ' . $row['apellido_cliente']) ?></td>

            <?php if ($rol === "admin" || $rol === "mecanico"): ?>
              <td class="acciones">
                <div class="acciones-wrap">
                  <button class="btn" type="button"
                    onclick='openEditar(<?= json_encode($row, JSON_UNESCAPED_UNICODE) ?>)'>
                    Editar
                  </button>

                  <?php if ($rol === "admin"): ?>
                    <button class="btn danger" type="button"
                      onclick='openEliminar(<?= json_encode($row["patente"], JSON_UNESCAPED_UNICODE) ?>)'>
                      Eliminar
                    </button>
                  <?php endif; ?>
                </div>
              </td>
            <?php endif; ?>

          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
    </div>

    <?php if ($rol === "mecanico"): ?>
      <p style="margin-top:.75rem;"><em>Modo Mecánico: puede editar datos técnicos del vehículo.</em></p>
    <?php endif; ?>
  </section>
</main>

<!-- ===================== MODALES ===================== -->

<!-- CREAR (admin) -->
<div class="modal" id="modalCrear" role="dialog" aria-modal="true" aria-labelledby="tCrear">
  <div class="box">
    <h3 id="tCrear">Crear Vehículo</h3>
    <form method="post">
      <input type="hidden" name="accion" value="crear">

      <div class="row">
        <div>
          <label>Patente</label>
          <input name="patente" required maxlength="6" placeholder="AB1234">
        </div>
        <div>
          <label>RUN Cliente (FK)</label>
          <input name="run" required placeholder="12345678-9">
        </div>
      </div>

      <div class="row">
        <div>
          <label>Marca (ID opcional)</label>
          <input type="number" name="id_marca" min="1" placeholder="id_marca">
        </div>
        <div>
          <label>Transmisión</label>
          <input name="transmision" placeholder="Manual / Automática">
        </div>
      </div>

      <div class="row">
        <div>
          <label>Cilindrada</label>
          <input type="number" name="cilindrada" min="0">
        </div>
        <div>
          <label>Color</label>
          <input name="color" required>
        </div>
      </div>

      <div class="row">
        <div>
          <label>Motor</label>
          <input name="motor">
        </div>
      </div>

      <div class="actions" style="margin-top:1rem;">
        <button class="btn" type="submit">Crear</button>
        <button class="btn" type="button" onclick="closeModal('modalCrear')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<!-- EDITAR (admin + mecánico) -->
<div class="modal" id="modalEditar" role="dialog" aria-modal="true" aria-labelledby="tEditar">
  <div class="box">
    <h3 id="tEditar">Editar Vehículo</h3>
    <form method="post">
      <input type="hidden" name="accion" value="editar">
      <input type="hidden" name="patente" id="e_patente">

      <p style="margin:.25rem 0 .75rem;">
        Patente: <strong id="e_patente_label"></strong>
      </p>

      <?php if ($rol === "admin"): ?>
      <div class="row">
        <div>
          <label>RUN Cliente (FK)</label>
          <input name="run" id="e_run" required>
        </div>
        <div>
          <label>Marca (ID opcional)</label>
          <input type="number" name="id_marca" id="e_id_marca" min="1">
        </div>
      </div>
      <?php endif; ?>

      <div class="row">
        <div>
          <label>Transmisión</label>
          <input name="transmision" id="e_transmision">
        </div>
        <div>
          <label>Cilindrada</label>
          <input type="number" name="cilindrada" id="e_cilindrada" min="0">
        </div>
      </div>

      <div class="row">
        <div>
          <label>Color</label>
          <input name="color" id="e_color" required>
        </div>
        <div>
          <label>Motor</label>
          <input name="motor" id="e_motor">
        </div>
      </div>

      <div class="actions" style="margin-top:1rem;">
        <button class="btn" type="submit">Guardar</button>
        <button class="btn" type="button" onclick="closeModal('modalEditar')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<!-- ELIMINAR (admin) -->
<div class="modal" id="modalEliminar" role="dialog" aria-modal="true" aria-labelledby="tEliminar">
  <div class="box">
    <h3 id="tEliminar">Eliminar Vehículo</h3>
    <p>¿Seguro que deseas eliminar este vehículo?</p>
    <form method="post">
      <input type="hidden" name="accion" value="eliminar">
      <input type="hidden" name="patente" id="d_patente">
      <div class="actions" style="margin-top:1rem;">
        <button class="btn danger" type="submit">Eliminar</button>
        <button class="btn" type="button" onclick="closeModal('modalEliminar')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<script>
function openModal(id){ document.getElementById(id).classList.add("is-open"); }
function closeModal(id){ document.getElementById(id).classList.remove("is-open"); }

document.querySelectorAll(".modal").forEach(m=>{
  m.addEventListener("click", (e)=>{ if(e.target === m) m.classList.remove("is-open"); });
});

function openEditar(v){
  document.getElementById("e_patente").value = v.patente ?? "";
  document.getElementById("e_patente_label").textContent = v.patente ?? "";

  // comunes
  document.getElementById("e_transmision").value = v.transmision ?? "";
  document.getElementById("e_cilindrada").value = v.cilindrada ?? "";
  document.getElementById("e_color").value = v.color ?? "";
  document.getElementById("e_motor").value = v.motor ?? "";

  // admin-only 
  const runEl = document.getElementById("e_run");
  if (runEl) runEl.value = v.run_cliente ?? "";

  const marcaEl = document.getElementById("e_id_marca");
  if (marcaEl) marcaEl.value = v.id_marca ?? "";

  openModal("modalEditar");
}

function openEliminar(patente){
  document.getElementById("d_patente").value = patente;
  openModal("modalEliminar");
}
</script>

<footer>
  <small>MIAUtomotriz — Universidad de Los Lagos — 2025</small>
</footer>
</body>
</html>

