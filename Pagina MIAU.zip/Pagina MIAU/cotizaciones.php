<?php
require "db.php";
session_start();

if (!isset($_SESSION["usuario"])) {
    header("Location: index.php");
    exit();
}

$rol = $_SESSION["rol"] ?? "mecanico";
$conn = conectarDB();

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, "UTF-8"); }

/* =========================================================
   POST: CRUD (solo admin)
   ========================================================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $accion = $_POST["accion"] ?? "";

    if ($rol !== "admin") {
        header("Location: cotizaciones.php");
        exit();
    }

    if ($accion === "crear") {
        $numero       = (int)($_POST["numero"] ?? 0);
        $fechaemision = $_POST["fechaemision"] ?? null;
        $fechavalidez = $_POST["fechavalidez"] ?? null;
        $diasdevalidez = ($_POST["diasdevalidez"] === "" ? null : (int)$_POST["diasdevalidez"]);

        $sql = "
            INSERT INTO cotizacion (numero, fechaemision, fechavalidez, diasdevalidez)
            VALUES ($1,$2,$3,$4)
        ";
        @pg_query_params($conn, $sql, [$numero, $fechaemision, $fechavalidez, $diasdevalidez]);

        header("Location: cotizaciones.php");
        exit();
    }

    if ($accion === "editar") {
        $numero       = (int)($_POST["numero"] ?? 0);
        $fechaemision = $_POST["fechaemision"] ?? null;
        $fechavalidez = $_POST["fechavalidez"] ?? null;
        $diasdevalidez = ($_POST["diasdevalidez"] === "" ? null : (int)$_POST["diasdevalidez"]);

        $sql = "
            UPDATE cotizacion
            SET fechaemision = $1,
                fechavalidez = $2,
                diasdevalidez = $3
            WHERE numero = $4
        ";
        @pg_query_params($conn, $sql, [$fechaemision, $fechavalidez, $diasdevalidez, $numero]);

        header("Location: cotizaciones.php");
        exit();
    }

    if ($accion === "eliminar") {
        $numero = (int)($_POST["numero"] ?? 0);

        $sql = "DELETE FROM cotizacion WHERE numero = $1";
        @pg_query_params($conn, $sql, [$numero]);

        header("Location: cotizaciones.php");
        exit();
    }

    header("Location: cotizaciones.php");
    exit();
}

$busqueda = trim($_GET["q"] ?? "");

if ($busqueda !== "") {
    $sql = "
        SELECT numero, fechaemision, fechavalidez, diasdevalidez
        FROM cotizacion
        WHERE numero::text ILIKE $1
           OR COALESCE(diasdevalidez::text,'') ILIKE $1
           OR COALESCE(fechaemision::text,'') ILIKE $1
           OR COALESCE(fechavalidez::text,'') ILIKE $1
        ORDER BY numero DESC
    ";
    $result = pg_query_params($conn, $sql, ['%'.$busqueda.'%']);
} else {
    $sql = "
        SELECT numero, fechaemision, fechavalidez, diasdevalidez
        FROM cotizacion
        ORDER BY numero DESC
    ";
    $result = pg_query($conn, $sql);
}

if (!$result) {
    die("Error al ejecutar la consulta de cotizaciones.");
}
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Cotizaciones — MIAUtomotriz</title>
  <link rel="stylesheet" href="./static/css/styles.css" />
  <style>
    .modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);padding:1rem;z-index:9999;}
    .modal.is-open{display:flex;align-items:center;justify-content:center;}
    .modal .box{background:#fff;border-radius:12px;max-width:720px;width:100%;padding:1rem;}
    .row{display:flex;gap:.75rem;flex-wrap:wrap}
    .row > div{flex:1;min-width:220px}
    .actions{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center}
    .btn{padding:.35rem .6rem;border:1px solid #999;border-radius:8px;background:#f7f7f7;cursor:pointer;text-decoration:none;color:#000}
    .btn.danger{border-color:#b00020}
    input{width:100%}
    table{width:100%;border-collapse:collapse}
    th,td{border-bottom:1px solid #ddd;padding:.5rem;text-align:left}
    .toolbar{display:flex;gap:.5rem;flex-wrap:wrap;align-items:center}
  </style>
</head>

<body class="app-<?= h($rol) ?>">
<header>
  <a class="brand" href="dashboard.php" aria-label="Ir al dashboard">
  <img src="/static/img/logo.png" alt="MIAUtomotriz">
  </a>
  <h1>MIAUtomotriz</h1>
  <p class="tagline">Cotizaciones</p>
  <nav aria-label="principal">
    <ul>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="index.php">Salir</a></li>
    </ul>
  </nav>
</header>

<main>
  <section>
    <h2>Listado de cotizaciones</h2>

    <form method="get" class="toolbar">
      <label for="q">Buscar:</label>
      <input id="q" name="q" placeholder="Número, fecha o días de validez" value="<?= h($busqueda) ?>" style="max-width:360px;">
      <button class="btn" type="submit">Buscar</button>

      <?php if ($busqueda !== ""): ?>
        <a class="btn" href="cotizaciones.php">Limpiar</a>
      <?php endif; ?>

      <?php if ($rol === "admin"): ?>
        <button class="btn" type="button" onclick="openModal('modalCrear')">+ Nueva cotización</button>
      <?php endif; ?>
    </form>

    <div style="overflow:auto;margin-top:1rem;">
      <table>
        <thead>
          <tr>
            <th>N°</th>
            <th>Fecha emisión</th>
            <th>Fecha validez</th>
            <th>Días de validez</th>
            <?php if ($rol === "admin"): ?>
              <th>Acciones</th>
            <?php endif; ?>
          </tr>
        </thead>

        <tbody>
          <?php while ($row = pg_fetch_assoc($result)): ?>
          <tr>
            <td><?= h($row["numero"]) ?></td>
            <td><?= h($row["fechaemision"]) ?></td>
            <td><?= h($row["fechavalidez"]) ?></td>
            <td><?= h($row["diasdevalidez"] ?? "") ?></td>

            <td class="actions">
              <!-- PDF (admin y mecánico) -->
              <a class="btn"
                href="export_pdf.php?doc=cotizacion&numero=<?= (int)$row["numero"] ?>"
                target="_blank">
                PDF
              </a>

              <?php if ($rol === "admin"): ?>
                <button class="btn" type="button"
                  onclick='openEditar(<?= json_encode($row, JSON_UNESCAPED_UNICODE) ?>)'>
                  Editar
                </button>

                <button class="btn danger" type="button"
                  onclick='openEliminar(<?= (int)$row["numero"] ?>)'>
                  Eliminar
                </button>
              <?php endif; ?>
            </td>
          </tr>
          <?php endwhile; ?>
        </tbody>
      </table>
    </div>

    <?php if ($rol !== "admin"): ?>
      <p style="margin-top:.75rem;"><em>Modo Mecánico: solo lectura.</em></p>
    <?php endif; ?>
  </section>
</main>

<!-- ===================== MODALES  ===================== -->

<div class="modal" id="modalCrear" role="dialog" aria-modal="true" aria-labelledby="tCrear">
  <div class="box">
    <h3 id="tCrear">Crear cotización</h3>
    <form method="post">
      <input type="hidden" name="accion" value="crear">

      <div class="row">
        <div>
          <label>Número (PK)</label>
          <input type="number" name="numero" min="1" required>
        </div>
        <div>
          <label>Días de validez</label>
          <input type="number" name="diasdevalidez" min="0">
        </div>
      </div>

      <div class="row">
        <div>
          <label>Fecha emisión</label>
          <input type="date" name="fechaemision">
        </div>
        <div>
          <label>Fecha validez</label>
          <input type="date" name="fechavalidez">
        </div>
      </div>

      <div class="actions" style="margin-top:1rem;">
        <button class="btn" type="submit">Crear</button>
        <button class="btn" type="button" onclick="closeModal('modalCrear')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<div class="modal" id="modalEditar" role="dialog" aria-modal="true" aria-labelledby="tEditar">
  <div class="box">
    <h3 id="tEditar">Editar cotización</h3>
    <form method="post">
      <input type="hidden" name="accion" value="editar">

      <div class="row">
        <div>
          <label>Número (no editable)</label>
          <input type="number" name="numero" id="e_numero" readonly>
        </div>
        <div>
          <label>Días de validez</label>
          <input type="number" name="diasdevalidez" id="e_dias" min="0">
        </div>
      </div>

      <div class="row">
        <div>
          <label>Fecha emisión</label>
          <input type="date" name="fechaemision" id="e_emision">
        </div>
        <div>
          <label>Fecha validez</label>
          <input type="date" name="fechavalidez" id="e_validez">
        </div>
      </div>

      <div class="actions" style="margin-top:1rem;">
        <button class="btn" type="submit">Guardar</button>
        <button class="btn" type="button" onclick="closeModal('modalEditar')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<div class="modal" id="modalEliminar" role="dialog" aria-modal="true" aria-labelledby="tEliminar">
  <div class="box">
    <h3 id="tEliminar">Eliminar cotización</h3>
    <p>¿Seguro que deseas eliminar esta cotización?</p>
    <form method="post">
      <input type="hidden" name="accion" value="eliminar">
      <input type="hidden" name="numero" id="d_numero">
      <div class="actions" style="margin-top:1rem;">
        <button class="btn danger" type="submit">Eliminar</button>
        <button class="btn" type="button" onclick="closeModal('modalEliminar')">Cancelar</button>
      </div>
    </form>
  </div>
</div>

<script>
function openModal(id){ document.getElementById(id).classList.add("is-open"); }
function closeModal(id){ document.getElementById(id).classList.remove("is-open"); }

document.querySelectorAll(".modal").forEach(m=>{
  m.addEventListener("click", (e)=>{ if(e.target === m) m.classList.remove("is-open"); });
});

function openEditar(c){
  document.getElementById("e_numero").value = c.numero ?? "";
  document.getElementById("e_dias").value = c.diasdevalidez ?? "";
  document.getElementById("e_emision").value = (c.fechaemision ?? "").substring(0,10);
  document.getElementById("e_validez").value = (c.fechavalidez ?? "").substring(0,10);
  openModal("modalEditar");
}

function openEliminar(numero){
  document.getElementById("d_numero").value = numero;
  openModal("modalEliminar");
}
</script>

<footer>
  <small>MIAUtomotriz — Universidad de Los Lagos — 2025</small>
</footer>
</body>
</html>

