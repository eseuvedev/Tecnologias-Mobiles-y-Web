<?php
require "db.php";
session_start();

$conn = conectarDB();

if (isset($_GET["api"])) {

    header("Content-Type: application/json; charset=utf-8");

    if (!isset($_SESSION["usuario"])) {
        http_response_code(401);
        echo json_encode(["error" => "No autenticado"]);
        exit();
    }

    /* ===== INGRESOS MENSUALES ===== */
    if ($_GET["api"] === "ingresos_mensuales") {

        $sql = "
            SELECT 
                to_char(date_trunc('month', f.fecha), 'YYYY-MM') AS mes,
                COALESCE(SUM(df.total), 0) AS ingresos
            FROM factura f
            JOIN detallefactura df ON df.id_detalle = f.id_detalle
            GROUP BY 1
            ORDER BY 1;
        ";

        $res = pg_query($conn, $sql);

        $labels = [];
        $data   = [];

        while ($row = pg_fetch_assoc($res)) {
            $labels[] = $row["mes"];
            $data[]   = (float)$row["ingresos"];
        }

        echo json_encode(["labels" => $labels, "data" => $data]);
        exit();
    }

    /* ===== REPUESTOS MÁS UTILIZADOS (TOP 5) ===== */
    if ($_GET["api"] === "repuestos_top5") {

        $sql = "
            SELECT 
                p.nombre AS repuesto,
                COUNT(*) AS usos
            FROM ordenrequierepieza orp
            JOIN pieza p ON p.codigo = orp.codigo_pieza
            GROUP BY p.nombre
            ORDER BY usos DESC
            LIMIT 5;
        ";

        $res = pg_query($conn, $sql);

        $labels = [];
        $data   = [];

        while ($row = pg_fetch_assoc($res)) {
            $labels[] = $row["repuesto"];
            $data[]   = (int)$row["usos"];
        }

        echo json_encode(["labels" => $labels, "data" => $data]);
        exit();
    }

    /* ===== AVERÍAS MÁS COMUNES ===== */
    if ($_GET["api"] === "averias_comunes") {

        $sql = "
            SELECT 
                COALESCE(a.causa, 'Sin causa') AS causa,
                COUNT(*) AS cantidad
            FROM vehiculodocumentaaveria vda
            JOIN averia a ON a.codigo = vda.codigo_averia
            GROUP BY 1
            ORDER BY cantidad DESC;
        ";

        $res = pg_query($conn, $sql);

        $labels = [];
        $data   = [];

        while ($row = pg_fetch_assoc($res)) {
            $labels[] = $row["causa"];
            $data[]   = (int)$row["cantidad"];
        }

        echo json_encode(["labels" => $labels, "data" => $data]);
        exit();
    }

    /* ===== RENDIMIENTO: VEHÍCULOS ATENDIDOS POR MES (OT por mes) ===== */
    if ($_GET["api"] === "vehiculos_mes") {

        $sql = "
            SELECT
                to_char(date_trunc('month', o.fecha), 'YYYY-MM') AS mes,
                COUNT(*)::int AS cantidad
            FROM ordendetrabajo o
            GROUP BY 1
            ORDER BY 1;
        ";

        $res = pg_query($conn, $sql);

        $labels = [];
        $data   = [];

        while ($row = pg_fetch_assoc($res)) {
            $labels[] = $row["mes"];
            $data[]   = (int)$row["cantidad"];
        }

        echo json_encode(["labels" => $labels, "data" => $data]);
        exit();
    }

    http_response_code(400);
    echo json_encode(["error" => "API no válida"]);
    exit();
}

/* =====================================================
   HTML NORMAL (DESPUÉS DEL API)
   ===================================================== */
if (!isset($_SESSION["usuario"])) {
    header("Location: index.php");
    exit();
}

$rol = $_SESSION["rol"] ?? "mecanico";
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Dashboard — Estadísticas</title>

  <link rel="stylesheet" href="./static/css/styles.css" />

  <!-- Chart.js -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

  <style>
    .grid {
      display: grid;
      grid-template-columns: 1fr;
      gap: 1rem;
    }
    @media (min-width: 900px) {
      .grid { grid-template-columns: 1fr 1fr; }
    }
    .card {
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 14px;
      padding: 1rem;
    }
    canvas { max-height: 340px; }
  </style>
</head>

<body class="app-<?= htmlspecialchars($rol) ?>">
<header>
  <a class="brand" href="dashboard.php" aria-label="Ir al dashboard">
  <img src="/static/img/logo.png" alt="MIAUtomotriz">
  </a>

  <h1>MIAUtomotriz</h1>
  <p class="tagline">Dashboard — Estadísticas</p>
  <nav>
    <ul>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a href="index.php">Salir</a></li>
    </ul>
  </nav>
</header>

<main>
  <section class="grid">
    <div class="card">
      <h3>Ingresos Mensuales</h3>
      <canvas id="chartIngresos"></canvas>
    </div>

    <div class="card">
      <h3>Rendimiento del Taller</h3>
      <p style="opacity:.85;margin-top:.25rem;">
        Vehículos atendidos por mes (estimado por cantidad de Órdenes de Trabajo).
      </p>
      <canvas id="chartRendimiento"></canvas>
    </div>

    <div class="card">
      <h3>Repuestos Más Utilizados (Top 5)</h3>
      <canvas id="chartRepuestos"></canvas>
    </div>

    <div class="card">
      <h3>Averías Más Comunes</h3>
      <canvas id="chartAverias"></canvas>
    </div>
  </section>
</main>

<footer>
  <small>MIAUtomotriz — Universidad de Los Lagos — 2025</small>
</footer>

<script>
async function fetchJSON(url) {
  const res = await fetch(url, { credentials: "same-origin" });
  if (!res.ok) throw new Error("Error API");
  return res.json();
}

/* ===== INGRESOS ===== */
async function loadIngresos() {
  const data = await fetchJSON("?api=ingresos_mensuales");

  new Chart(document.getElementById("chartIngresos"), {
    type: "bar",
    data: {
      labels: data.labels,
      datasets: [{ label: "Ingresos", data: data.data }]
    },
    options: {
      responsive: true,
      scales: { y: { beginAtZero: true } }
    }
  });
}

/* ===== RENDIMIENTO (línea) ===== */
async function loadRendimiento() {
  const data = await fetchJSON("?api=vehiculos_mes");

  new Chart(document.getElementById("chartRendimiento"), {
    type: "line",
    data: {
      labels: data.labels,
      datasets: [{ label: "Vehículos atendidos", data: data.data, tension: 0.25 }]
    },
    options: {
      responsive: true,
      scales: { y: { beginAtZero: true } }
    }
  });
}

/* ===== REPUESTOS ===== */
async function loadRepuestos() {
  const data = await fetchJSON("?api=repuestos_top5");

  new Chart(document.getElementById("chartRepuestos"), {
    type: "bar",
    data: {
      labels: data.labels,
      datasets: [{ label: "Usos", data: data.data }]
    },
    options: {
      indexAxis: "y",
      responsive: true,
      scales: { x: { beginAtZero: true } }
    }
  });
}

/* ===== AVERÍAS ===== */
async function loadAverias() {
  const data = await fetchJSON("?api=averias_comunes");

  new Chart(document.getElementById("chartAverias"), {
    type: "pie",
    data: {
      labels: data.labels,
      datasets: [{ data: data.data }]
    },
    options: { responsive: true }
  });
}

/* CARGA INICIAL */
loadIngresos();
loadRendimiento();
loadRepuestos();
loadAverias();
</script>
</body>
</html>

