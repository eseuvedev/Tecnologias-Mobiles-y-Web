<?php
require "db.php";
session_start();

if (!isset($_SESSION["usuario"])) {
    header("Location: index.php");
    exit();
}

require __DIR__ . "/lib/fpdf/fpdf.php";

$conn = conectarDB();
$rol  = $_SESSION["rol"] ?? "mecanico";

function hpdf($txt){
    return iconv("UTF-8", "ISO-8859-1//TRANSLIT", (string)$txt);
}

function moneyCLP($n){
    if ($n === null || $n === "") return "";
    return "$ " . number_format((float)$n, 0, ",", ".");
}

class PDF extends FPDF {
    function Header(){
        $this->SetFont("Arial","B",14);
        $this->Cell(0,8,hpdf("MIAUtomotriz"),0,1,"L");
        $this->SetFont("Arial","",10);
        $this->Cell(0,6,hpdf("Taller Automotriz — Documento generado por el sistema"),0,1,"L");
        $this->Ln(2);
        $this->Line(10, 26, 200, 26);
        $this->Ln(6);
    }
    function Footer(){
        $this->SetY(-15);
        $this->SetFont("Arial","I",8);
        $this->Cell(0,10,hpdf("Página ") . $this->PageNo(),0,0,"C");
    }
    function SectionTitle($t){
        $this->SetFont("Arial","B",11);
        $this->SetFillColor(240,240,240);
        $this->Cell(0,7,hpdf($t),0,1,"L",true);
        $this->Ln(1);
    }
    function KV($k, $v){
        $this->SetFont("Arial","B",9);
        $this->Cell(45,6,hpdf($k),0,0,"L");
        $this->SetFont("Arial","",9);
        $this->Cell(0,6,hpdf($v),0,1,"L");
    }
    function TableHeader($cols){
        $this->SetFont("Arial","B",9);
        $this->SetFillColor(220,220,220);
        foreach($cols as $c){
            $this->Cell($c[1],7,hpdf($c[0]),1,0,"L",true);
        }
        $this->Ln();
    }
    function TableRow($cols){
        $this->SetFont("Arial","",9);
        foreach($cols as $c){
            $this->Cell($c[1],7,hpdf($c[0]),1,0,"L");
        }
        $this->Ln();
    }
}

$doc = $_GET["doc"] ?? "";

if (!in_array($doc, ["ot","factura","cotizacion"], true)) {
    http_response_code(400);
    echo "Parámetro doc inválido.";
    exit();
}

$pdf = new PDF("P","mm","A4");
$pdf->SetAutoPageBreak(true, 18);
$pdf->AddPage();

/* =========================================================
   1) ORDEN DE TRABAJO (doc=ot&numero_orden=...)
   ========================================================= */
if ($doc === "ot") {
    $numero_orden = (int)($_GET["numero_orden"] ?? 0);
    if ($numero_orden <= 0) { die("Falta numero_orden"); }

    // OT + Cliente + Vehículo
    $sqlOT = "
        SELECT
            o.numero_orden, o.fecha,
            c.run, c.nombre AS c_nombre, c.apellido AS c_apellido,
            v.patente, v.color, v.transmision, v.cilindrada, v.motor,
            o.id_detalleorden
        FROM ordendetrabajo o
        JOIN cliente c ON c.run = o.run
        JOIN vehiculo v ON v.patente = o.patente
        WHERE o.numero_orden = $1
        LIMIT 1;
    ";
    $resOT = pg_query_params($conn, $sqlOT, [$numero_orden]);
    $ot = $resOT ? pg_fetch_assoc($resOT) : null;
    if (!$ot) { die("OT no encontrada."); }

    // Detalle Orden 
    $detalle = null;
    if (!empty($ot["id_detalleorden"])) {
        $sqlDet = "SELECT * FROM detalleorden WHERE id_detalleorden = $1 LIMIT 1;";
        $resDet = pg_query_params($conn, $sqlDet, [(int)$ot["id_detalleorden"]]);
        $detalle = $resDet ? pg_fetch_assoc($resDet) : null;
    }

    // Daños por vehículo
    $sqlDan = "
        SELECT d.parte, d.lugar, d.descripcion, dv.estado
        FROM danosvehiculos dv
        JOIN danos d ON d.codigo = dv.codigo_danos
        WHERE dv.patente = $1
        ORDER BY d.parte;
    ";
    $resDan = pg_query_params($conn, $sqlDan, [$ot["patente"]]);

    // Averías por vehículo
    $sqlAv = "
        SELECT a.causa, a.lugar, a.descripcion, vda.estado
        FROM vehiculodocumentaaveria vda
        JOIN averia a ON a.codigo = vda.codigo_averia
        WHERE vda.patente = $1
        ORDER BY a.causa;
    ";
    $resAv = pg_query_params($conn, $sqlAv, [$ot["patente"]]);

    // Repuestos por OT (ordenrequierepieza)
    $sqlRep = "
        SELECT orp.codigo_pieza, p.nombre, orp.montocompra, orp.id_compra
        FROM ordenrequierepieza orp
        JOIN pieza p ON p.codigo = orp.codigo_pieza
        WHERE orp.numero_orden = $1
        ORDER BY p.nombre;
    ";
    $resRep = pg_query_params($conn, $sqlRep, [$numero_orden]);

    $pdf->SectionTitle("ORDEN DE TRABAJO");
    $pdf->KV("N° Orden:", $ot["numero_orden"]);
    $pdf->KV("Fecha:", $ot["fecha"]);
    $pdf->Ln(2);

    $pdf->SectionTitle("Datos del Cliente");
    $pdf->KV("RUN:", $ot["run"]);
    $pdf->KV("Nombre:", $ot["c_nombre"] . " " . $ot["c_apellido"]);
    $pdf->Ln(2);

    $pdf->SectionTitle("Datos del Vehículo");
    $pdf->KV("Patente:", $ot["patente"]);
    $pdf->KV("Color:", $ot["color"]);
    $pdf->KV("Transmisión:", $ot["transmision"]);
    $pdf->KV("Cilindrada:", $ot["cilindrada"]);
    $pdf->KV("Motor:", $ot["motor"]);
    $pdf->Ln(2);

    if ($detalle) {
        $pdf->SectionTitle("Registro Operativo (Detalle Orden)");
        $pdf->KV("Kilometraje:", $detalle["kilometraje"] ?? "");
        $pdf->KV("Combustible disponible (%):", $detalle["combustibledisponible"] ?? "");
        $pdf->KV("Total repuestos:", $detalle["totalrepuestos"] ?? "");
        $pdf->Ln(2);
    }

    $pdf->SectionTitle("Daños registrados");
    $pdf->TableHeader([
        ["Parte", 40], ["Lugar", 35], ["Descripción", 90], ["Estado", 25]
    ]);
    if ($resDan) {
        $has = false;
        while ($r = pg_fetch_assoc($resDan)) {
            $has = true;
            $pdf->TableRow([
                [$r["parte"] ?? "", 40],
                [$r["lugar"] ?? "", 35],
                [$r["descripcion"] ?? "", 90],
                [$r["estado"] ?? "", 25],
            ]);
        }
        if (!$has) $pdf->TableRow([["Sin registros", 190]]);
    } else {
        $pdf->TableRow([["Sin registros", 190]]);
    }
    $pdf->Ln(2);

    $pdf->SectionTitle("Averías registradas");
    $pdf->TableHeader([
        ["Causa", 45], ["Lugar", 35], ["Descripción", 85], ["Estado", 25]
    ]);
    if ($resAv) {
        $has = false;
        while ($r = pg_fetch_assoc($resAv)) {
            $has = true;
            $pdf->TableRow([
                [$r["causa"] ?? "", 45],
                [$r["lugar"] ?? "", 35],
                [$r["descripcion"] ?? "", 85],
                [$r["estado"] ?? "", 25],
            ]);
        }
        if (!$has) $pdf->TableRow([["Sin registros", 190]]);
    } else {
        $pdf->TableRow([["Sin registros", 190]]);
    }
    $pdf->Ln(2);

    $pdf->SectionTitle("Repuestos utilizados en la OT");
    $pdf->TableHeader([
        ["Código", 25], ["Repuesto", 105], ["Monto", 30], ["ID Compra", 30]
    ]);
    if ($resRep) {
        $has = false;
        while ($r = pg_fetch_assoc($resRep)) {
            $has = true;
            $pdf->TableRow([
                [$r["codigo_pieza"], 25],
                [$r["nombre"], 105],
                [moneyCLP($r["montocompra"]), 30],
                [$r["id_compra"], 30]
            ]);
        }
        if (!$has) $pdf->TableRow([["Sin repuestos asociados", 190]]);
    } else {
        $pdf->TableRow([["Sin repuestos asociados", 190]]);
    }

    $pdf->Ln(4);
    $pdf->SetFont("Arial","I",9);
    $pdf->MultiCell(0,5,hpdf("Nota: este documento no incluye 'estado' o 'notas' porque el modelo de datos no contempla atributos persistentes para ello."));
    $pdf->Output("I", "OT_" . $numero_orden . ".pdf");
    exit();
}

/* =========================================================
   2) FACTURA/BOLETA (doc=factura&codigo_factura=...)
   ========================================================= */
if ($doc === "factura") {
    $codigo_factura = (int)($_GET["codigo_factura"] ?? 0);
    if ($codigo_factura <= 0) { die("Falta codigo_factura"); }

    $sqlF = "
        SELECT
            f.codigo_factura, f.fecha,
            f.numero AS numero_cotizacion,
            f.nombre_aseguradora,
            df.id_detalle, df.valorneto, df.iva, df.total, df.detalles, df.cantidad, df.descuento, df.preciounitario, df.estado
        FROM factura f
        JOIN detallefactura df ON df.id_detalle = f.id_detalle
        WHERE f.codigo_factura = $1
        LIMIT 1;
    ";
    $resF = pg_query_params($conn, $sqlF, [$codigo_factura]);
    $fac = $resF ? pg_fetch_assoc($resF) : null;
    if (!$fac) { die("Factura no encontrada."); }

    $pdf->SectionTitle("FACTURA / BOLETA");
    $pdf->KV("Código factura:", $fac["codigo_factura"]);
    $pdf->KV("Fecha:", $fac["fecha"]);
    $pdf->KV("Cotización asociada N°:", $fac["numero_cotizacion"]);
    $pdf->KV("Aseguradora:", $fac["nombre_aseguradora"] ?: "N/A");
    $pdf->Ln(2);

    $pdf->SectionTitle("Detalle");
    $pdf->TableHeader([
        ["Detalle", 95], ["Cant.", 15], ["Unit.", 25], ["Desc.", 20], ["Total", 35]
    ]);
    $pdf->TableRow([
        [$fac["detalles"] ?: "Item", 95],
        [$fac["cantidad"] ?? "", 15],
        [moneyCLP($fac["preciounitario"]), 25],
        [($fac["descuento"] ?? "") . "%", 20],
        [moneyCLP($fac["total"]), 35],
    ]);

    $pdf->Ln(3);
    $pdf->SectionTitle("Totales");
    $pdf->KV("Neto:", moneyCLP($fac["valorneto"]));
    $pdf->KV("IVA:", moneyCLP($fac["iva"]));
    $pdf->KV("TOTAL:", moneyCLP($fac["total"]));

    $pdf->Output("I", "FACTURA_" . $codigo_factura . ".pdf");
    exit();
}

/* =========================================================
   3) COTIZACIÓN (doc=cotizacion&numero=...)
   ========================================================= */
if ($doc === "cotizacion") {
    $numero = (int)($_GET["numero"] ?? 0);
    if ($numero <= 0) { die("Falta numero"); }

    $sqlC = "
        SELECT numero, fechaemision, fechavalidez, diasdevalidez
        FROM cotizacion
        WHERE numero = $1
        LIMIT 1;
    ";
    $resC = pg_query_params($conn, $sqlC, [$numero]);
    $cot = $resC ? pg_fetch_assoc($resC) : null;
    if (!$cot) { die("Cotización no encontrada."); }

    // Clientes asociados 
    $sqlCli = "
        SELECT c.run, c.nombre, c.apellido
        FROM cotizacionsolicitada cs
        JOIN cliente c ON c.run = cs.run
        WHERE cs.numero = $1
        ORDER BY c.apellido;
    ";
    $resCli = pg_query_params($conn, $sqlCli, [$numero]);

    // Mano de obra por cotización 
    $sqlMO = "
        SELECT mo.descripcion, mo.tarifaporhora, mic.horastrabajadas
        FROM manoinfluyecotizacion mic
        JOIN manodeobra mo ON mo.numero = mic.numero_manodeobra
        WHERE mic.numero_cotizacion = $1
        ORDER BY mo.descripcion;
    ";
    $resMO = pg_query_params($conn, $sqlMO, [$numero]);

    // Piezas externas en cotización 
    $sqlPE = "
        SELECT pe.nombre, pe.categoria, cpe.montocompra, cpe.id_compra
        FROM cotizacionpiezaexterna cpe
        JOIN piezaexterna pe ON pe.codigo = cpe.codigopiezaexterna
        WHERE cpe.numerocotizacion = $1
        ORDER BY pe.nombre;
    ";
    $resPE = pg_query_params($conn, $sqlPE, [$numero]);

    // Totales estimados 
    $totalMO = 0;
    if ($resMO) {
        while ($r = pg_fetch_assoc($resMO)) {
            $h = (int)($r["horastrabajadas"] ?? 0);
            $t = (float)($r["tarifaporhora"] ?? 0);
            $totalMO += ($h * $t);
        }
        pg_result_seek($resMO, 0);
    }

    $totalPE = 0;
    if ($resPE) {
        while ($r = pg_fetch_assoc($resPE)) {
            $totalPE += (float)($r["montocompra"] ?? 0);
        }
        pg_result_seek($resPE, 0);
    }

    $pdf->SectionTitle("COTIZACIÓN");
    $pdf->KV("Número:", $cot["numero"]);
    $pdf->KV("Fecha emisión:", $cot["fechaemision"]);
    $pdf->KV("Fecha validez:", $cot["fechavalidez"]);
    $pdf->KV("Días de validez:", $cot["diasdevalidez"]);
    $pdf->Ln(2);

    $pdf->SectionTitle("Datos del Taller");
    $pdf->KV("Nombre:", "MIAUtomotriz");
    $pdf->KV("Contacto:", "admin@miau.cl");
    $pdf->KV("Ciudad:", "—");
    $pdf->Ln(2);

    $pdf->SectionTitle("Cliente(s) asociado(s)");
    $pdf->TableHeader([["RUN", 35], ["Nombre", 155]]);
    $has = false;
    if ($resCli) {
        while ($r = pg_fetch_assoc($resCli)) {
            $has = true;
            $pdf->TableRow([[$r["run"], 35], [$r["nombre"]." ".$r["apellido"], 155]]);
        }
    }
    if (!$has) $pdf->TableRow([["Sin clientes asociados", 190]]);
    $pdf->Ln(2);

    $pdf->SectionTitle("Mano de Obra");
    $pdf->TableHeader([
        ["Descripción", 110], ["Tarifa/hr", 30], ["Horas", 20], ["Subtotal", 30]
    ]);
    $has = false;
    if ($resMO) {
        while ($r = pg_fetch_assoc($resMO)) {
            $has = true;
            $h = (int)($r["horastrabajadas"] ?? 0);
            $t = (float)($r["tarifaporhora"] ?? 0);
            $sub = $h * $t;
            $pdf->TableRow([
                [$r["descripcion"], 110],
                [moneyCLP($t), 30],
                [$h, 20],
                [moneyCLP($sub), 30]
            ]);
        }
    }
    if (!$has) $pdf->TableRow([["Sin mano de obra asociada", 190]]);
    $pdf->Ln(2);

    $pdf->SectionTitle("Piezas externas");
    $pdf->TableHeader([
        ["Nombre", 95], ["Categoría", 45], ["Monto", 25], ["ID Compra", 25]
    ]);
    $has = false;
    if ($resPE) {
        while ($r = pg_fetch_assoc($resPE)) {
            $has = true;
            $pdf->TableRow([
                [$r["nombre"], 95],
                [$r["categoria"] ?? "", 45],
                [moneyCLP($r["montocompra"]), 25],
                [$r["id_compra"], 25],
            ]);
        }
    }
    if (!$has) $pdf->TableRow([["Sin piezas externas asociadas", 190]]);
    $pdf->Ln(2);

    $pdf->SectionTitle("Resumen de Costos (estimado)");
    $pdf->KV("Total mano de obra:", moneyCLP($totalMO));
    $pdf->KV("Total piezas externas:", moneyCLP($totalPE));
    $pdf->KV("TOTAL estimado:", moneyCLP($totalMO + $totalPE));

    $pdf->Ln(4);
    $pdf->SetFont("Arial","I",9);
    $pdf->MultiCell(0,5,hpdf("Este PDF se genera a partir de las relaciones existentes del modelo (mano de obra y piezas externas)."));
    $pdf->Output("I", "COTIZACION_" . $numero . ".pdf");
    exit();
}
