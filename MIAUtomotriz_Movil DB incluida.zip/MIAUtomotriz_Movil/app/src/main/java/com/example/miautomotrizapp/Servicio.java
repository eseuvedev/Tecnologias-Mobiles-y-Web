package com.example.miautomotrizapp;

public class Servicio {
    private String nombre;
    private String descripcion;
    private String precio;
    private int imagen;

    public Servicio(String nombre, String descripcion, String precio, int imagen) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.imagen = imagen;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getPrecio() {
        return precio;
    }

    public int getImagen() {
        return imagen;
    }
}
