package com.example.miautomotrizapp.db;

// 2. Importaciones necesarias
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

// Importamos la clase 'Servicio'
import com.example.miautomotrizapp.Servicio;

import java.util.ArrayList;
import java.util.List;

// 3. Definición de la Clase
// Heredamos de SQLiteOpenHelper, la clase base de Android para bases de datos
public class AutomotrizDbHelper extends SQLiteOpenHelper {

    //Si cambias la estructura debe incrementar este número.
    private static final int DATABASE_VERSION = 1;
    // Nombre del archivo que se creará en el dispositivo.
    private static final String DATABASE_NAME = "automotriz.db";

    // Nombre de nuestra tabla
    public static final String TABLE_SERVICIOS = "servicios";

    // Nombres de las columnas de la tabla 'servicios'
    public static final String COLUMN_ID = "id"; // Primary Key
    public static final String COLUMN_NOMBRE = "nombre";
    public static final String COLUMN_DESCRIPCION = "descripcion";
    public static final String COLUMN_PRECIO = "precio";
    public static final String COLUMN_IMAGEN = "imagen";

    /**
     * 4. Constructor
     * Es obligatorio. Pasa la información al constructor 'padre' (SQLiteOpenHelper).
     */
    public AutomotrizDbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * 5. Método onCreate (Creación)
     * Se ejecuta UNA SOLA VEZ, la primera vez que la app intenta acceder a la BD.
     * Aquí es donde creamos las tablas.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Escribimos el comando SQL para crear la tabla
        String CREATE_TABLE_SERVICIOS = "CREATE TABLE " + TABLE_SERVICIOS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," // ID numérico, llave primaria, autoincrementable
                + COLUMN_NOMBRE + " TEXT," // Columna de texto
                + COLUMN_DESCRIPCION + " TEXT,"
                + COLUMN_PRECIO + " TEXT," // Lo guardamos como TEXT (String) como lo tienes en tu clase Servicio
                + COLUMN_IMAGEN + " INTEGER" + ")"; // Columna de número (para el ID del drawable)

        // Ejecutamos el comando SQL
        db.execSQL(CREATE_TABLE_SERVICIOS);
    }

    /**
     * 6. Método onUpgrade (Actualización)
     * Se ejecuta si cambias (aumentas) la DATABASE_VERSION.
     * Sirve para migrar datos o modificar la estructura.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Estrategia simple: si hay una nueva versión, borramos la tabla vieja...
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SERVICIOS);
        // ...y la volvemos a crear.
        onCreate(db);
    }

    //  MÉTODOS CRUD (Create, Read, Update, Delete)

    /**
     * C - (Create) Inserta un nuevo servicio en la base de datos
     */
    public long insertarServicio(Servicio servicio) {
        // 1. Obtenemos la base de datos en modo "escritura"
        SQLiteDatabase db = this.getWritableDatabase();

        // 2. Creamos un 'mapa' (ContentValues) con los valores a insertar
        //    (La columna ID no se pone, se autogenera)
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOMBRE, servicio.getNombre());
        values.put(COLUMN_DESCRIPCION, servicio.getDescripcion());
        values.put(COLUMN_PRECIO, servicio.getPrecio());
        values.put(COLUMN_IMAGEN, servicio.getImagen());

        // 3. Insertamos la nueva fila en la tabla 'servicios'
        //    db.insert() devuelve el ID de la fila nueva, o -1 si falló.
        long newRowId = db.insert(TABLE_SERVICIOS, null, values);

        // 4. Cerramos la conexión a la BD
        db.close();
        return newRowId;
    }

    /**
     * R - (Read) Lee todos los servicios de la base de datos
     */
    public List<Servicio> leerTodosLosServicios() {
        // 1. Creamos la lista donde guardaremos los resultados
        List<Servicio> listaServicios = new ArrayList<>();

        // 2. Obtenemos la base de datos en modo "lectura"
        SQLiteDatabase db = this.getReadableDatabase();

        // 3. Ejecutamos una consulta (query) para traer todo de la tabla
        //    Un 'Cursor' es como un puntero que apunta a los resultados
        Cursor cursor = db.query(
                TABLE_SERVICIOS,  // Nombre de la tabla
                null,             // null = trae todas las columnas
                null,             // Cláusula WHERE (null = sin filtro)
                null,             // Argumentos del WHERE
                null,             // Agrupar por (group by)
                null,             // Filtro de grupo (having)
                null              // Ordenar por (order by)
        );

        // 4. Obtenemos los "índices" (la posición) de cada columna.
        //    Es más rápido que preguntar por el nombre de la columna en cada iteración.
        int idIndex = cursor.getColumnIndex(COLUMN_ID);
        int nombreIndex = cursor.getColumnIndex(COLUMN_NOMBRE);
        int descIndex = cursor.getColumnIndex(COLUMN_DESCRIPCION);
        int precioIndex = cursor.getColumnIndex(COLUMN_PRECIO);
        int imagenIndex = cursor.getColumnIndex(COLUMN_IMAGEN);

        // 5. Iteramos sobre todos los resultados (filas)
        while (cursor.moveToNext()) {
            // Leemos los datos de la fila actual usando los índices
            int id = cursor.getInt(idIndex);
            String nombre = cursor.getString(nombreIndex);
            String descripcion = cursor.getString(descIndex);
            String precio = cursor.getString(precioIndex);
            int imagen = cursor.getInt(imagenIndex);

            // Creamos un objeto Servicio con los datos leídos
            Servicio servicio = new Servicio(nombre, descripcion, precio, imagen);
            servicio.setId(id); // ¡Importante! Asignamos el ID de la BD

            // Añadimos el objeto a nuestra lista
            listaServicios.add(servicio);
        }

        // 6. Cerramos el cursor (¡muy importante!)
        cursor.close();
        // 7. Cerramos la conexión a la BD
        db.close();

        // 8. Devolvemos la lista completa
        return listaServicios;
    }

    /**
     * U - (Update) Actualiza un servicio existente
     */
    public int actualizarServicio(Servicio servicio) {
        // 1. Obtenemos la BD en modo escritura
        SQLiteDatabase db = this.getWritableDatabase();

        // 2. Creamos el 'mapa' de valores que queremos modificar
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOMBRE, servicio.getNombre());
        values.put(COLUMN_DESCRIPCION, servicio.getDescripcion());
        values.put(COLUMN_PRECIO, servicio.getPrecio());
        values.put(COLUMN_IMAGEN, servicio.getImagen());

        // 3. Definimos el filtro (WHERE): ¿Qué fila queremos actualizar?
        //    Actualizaremos la fila DONDE la columna ID sea igual a '?'
        String selection = COLUMN_ID + " = ?";
        // 4. Definimos el valor para el '?' (el ID del servicio)
        String[] selectionArgs = { String.valueOf(servicio.getId()) };

        // 5. Ejecutamos la actualización
        //    db.update() devuelve el número de filas que fueron afectadas
        int count = db.update(
                TABLE_SERVICIOS,
                values,
                selection,
                selectionArgs);

        // 6. Cerramos la conexión
        db.close();
        return count; // Devolvemos cuántas filas se actualizaron (debería ser 1)
    }

    /**
     * D - (Delete) Elimina un servicio por su ID
     */
    public int eliminarServicio(int id) {
        // 1. Obtenemos la BD en modo escritura
        SQLiteDatabase db = this.getWritableDatabase();

        // 2. Definimos el filtro (WHERE): ¿Qué fila queremos borrar?
        //    Borraremos la fila DONDE la columna ID sea igual a '?'
        String selection = COLUMN_ID + " = ?";
        // 3. Definimos el valor para el '?'
        String[] selectionArgs = { String.valueOf(id) };

        // 4. Ejecutamos la eliminación
        //    db.delete() devuelve el número de filas que fueron eliminadas
        int deletedRows = db.delete(TABLE_SERVICIOS, selection, selectionArgs);

        // 5. Cerramos la conexión
        db.close();
        return deletedRows; // Devolvemos cuántas filas se borraron
    }
}