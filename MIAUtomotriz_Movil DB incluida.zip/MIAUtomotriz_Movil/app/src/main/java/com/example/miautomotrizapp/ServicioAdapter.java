package com.example.miautomotrizapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast; // Importamos Toast para mostrar mensajes

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

// ---> PASO 1.A: Importar tu DbHelper
import com.example.miautomotrizapp.db.AutomotrizDbHelper;

import java.util.List;

public class ServicioAdapter extends RecyclerView.Adapter<ServicioAdapter.ServicioViewHolder> {

    private Context context;
    private List<Servicio> listaServicios;

    // ---> PASO 1.B: Añadir el dbHelper al adaptador
    private AutomotrizDbHelper dbHelper;

    public ServicioAdapter(Context context, List<Servicio> listaServicios) {
        this.context = context;
        this.listaServicios = listaServicios;
        // ---> PASO 1.C: Inicializar el dbHelper en el constructor
        this.dbHelper = new AutomotrizDbHelper(context);
    }

    @NonNull
    @Override
    public ServicioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_servicio, parent, false);
        return new ServicioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ServicioViewHolder holder, int position) {
        Servicio servicio = listaServicios.get(position);

        holder.tvNombre.setText(servicio.getNombre());
        holder.tvDescripcion.setText(servicio.getDescripcion());
        holder.tvPrecio.setText(servicio.getPrecio());
        holder.ivIcono.setImageResource(servicio.getImagen());

        // Este es tu OnClickListener original (para ir a EscogerMecanicoActivity)
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, EscogerMecanicoActivity.class);
            intent.putExtra("nombreServicio", servicio.getNombre());
            intent.putExtra("precioServicio", servicio.getPrecio());
            context.startActivity(intent);
        });

        // ---> PASO 3: Ponerle un onClickListener en onBindViewHolder
        holder.ivEliminar.setOnClickListener(v -> {

            // Usamos 'getAdapterPosition()' para asegurarnos de tener la posición correcta
            int currentPosition = holder.getAdapterPosition();
            // Evitamos errores si el ítem está siendo eliminado
            if (currentPosition == RecyclerView.NO_POSITION) {
                return;
            }

            // Obtenemos el ID del servicio que vamos a borrar
            int idServicioParaEliminar = listaServicios.get(currentPosition).getId();

            // a. Eliminamos de la Base de Datos
            int filasEliminadas = dbHelper.eliminarServicio(idServicioParaEliminar);

            if (filasEliminadas > 0) {
                // b. Si se borró de la BD, lo quitamos de la lista
                listaServicios.remove(currentPosition);
                // c. Notificamos al adaptador que un ítem se quitó (para la animación)
                notifyItemRemoved(currentPosition);
                Toast.makeText(context, "Servicio eliminado", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Error al eliminar", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaServicios.size();
    }

    // Método para actualizar la lista (este lo hicimos antes)
    public void actualizarLista(List<Servicio> nuevaLista) {
        this.listaServicios.clear();
        this.listaServicios.addAll(nuevaLista);
        this.notifyDataSetChanged();
    }

    // --- ViewHolder ---
    public static class ServicioViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre, tvDescripcion, tvPrecio;
        ImageView ivIcono;
        // ---> PASO 2.A: Declarar el ImageView para el botón de eliminar
        ImageView ivEliminar;

        public ServicioViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvNombreServicio);
            tvDescripcion = itemView.findViewById(R.id.tvDescripcionServicio);
            tvPrecio = itemView.findViewById(R.id.tvPrecioServicio);
            ivIcono = itemView.findViewById(R.id.ivIconoServicio);

            // ---> PASO 2.B: Identificar el ivEliminarServicio (que pusimos en el XML)
            ivEliminar = itemView.findViewById(R.id.ivEliminarServicio);
        }
    }
}