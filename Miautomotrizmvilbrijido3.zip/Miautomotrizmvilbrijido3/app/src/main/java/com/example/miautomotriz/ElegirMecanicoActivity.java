package com.example.miautomotriz;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ElegirMecanicoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elegir_mecanico);

        Spinner spMecanicos = findViewById(R.id.spMecanicos);
        Button btnConfirmar = findViewById(R.id.btnConfirmarMecanico);

        ArrayList<String> mecanicos = new ArrayList<>();
        mecanicos.add("Seleccionar");
        mecanicos.add("Juan Pérez");
        mecanicos.add("María González");
        mecanicos.add("Carlos Soto");
        mecanicos.add("Ana Muñoz");

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, mecanicos
        );
        spMecanicos.setAdapter(adapter);

        btnConfirmar.setOnClickListener(v -> {
            String seleccionado = spMecanicos.getSelectedItem().toString();

            if (seleccionado.equals("Seleccionar")) {
                Toast.makeText(this, "Selecciona un mecánico", Toast.LENGTH_SHORT).show();
                return;
            }

            Toast.makeText(this, "Mecánico elegido: " + seleccionado, Toast.LENGTH_SHORT).show();

            ArrayList<Integer> ids = getIntent().getIntegerArrayListExtra("servicios_ids");
            String matricula = getIntent().getStringExtra("matricula");
            String modelo = getIntent().getStringExtra("modelo");

            Intent i = new Intent(this, CotizacionActivity.class);
            i.putIntegerArrayListExtra("servicios_ids", ids);
            i.putExtra("mecanico", seleccionado);
            i.putExtra("matricula", matricula);
            i.putExtra("modelo", modelo);
            startActivity(i);
            finish();
        });
    }
}
