package com.example.miautomotriz;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;

public class OrdenActualActivity extends AppCompatActivity {

    private TextView tvContenidoOrden;
    private Button btnCancelar, btnVolver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orden_actual);

        tvContenidoOrden = findViewById(R.id.tvContenidoOrden);
        btnCancelar = findViewById(R.id.btnCancelarOrden);
        btnVolver = findViewById(R.id.btnVolverHome);

        cargarOrden();

        btnCancelar.setOnClickListener(v -> cancelarOrden());

        btnVolver.setOnClickListener(v -> finish()); // vuelve a HomeActivity

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("");
    }

    private void cargarOrden() {
        SharedPreferences sp = getSharedPreferences("orden_actual", MODE_PRIVATE);

        String matricula = sp.getString("matricula", "");
        String modelo = sp.getString("modelo", "");

        // ✅ Si no hay auto guardado, no hay orden
        if (matricula.isEmpty() || modelo.isEmpty()) {
            tvContenidoOrden.setText("No hay orden");
            btnCancelar.setVisibility(View.GONE);
            return;
        }

        btnCancelar.setVisibility(View.VISIBLE);

        String mecanico = sp.getString("mecanico", "No asignado");
        String servicios = sp.getString("servicios", "Servicios:\n");
        int total = sp.getInt("total", 0);

        String texto =
                "Vehículo: " + modelo + " - Matrícula " + matricula + "\n\n" +
                        "Mecánico: " + mecanico + "\n\n" +
                        servicios + "\n" +
                        "Total: $" + total;

        tvContenidoOrden.setText(texto);
    }


    private void cancelarOrden() {
        getSharedPreferences("orden_actual", MODE_PRIVATE)
                .edit()
                .clear()
                .apply();

        Toast.makeText(this, "Orden cancelada", Toast.LENGTH_SHORT).show();

        tvContenidoOrden.setText("No hay orden");
        btnCancelar.setVisibility(Button.GONE); // 🔴 ocultar botón
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarOrden();
    }


}
