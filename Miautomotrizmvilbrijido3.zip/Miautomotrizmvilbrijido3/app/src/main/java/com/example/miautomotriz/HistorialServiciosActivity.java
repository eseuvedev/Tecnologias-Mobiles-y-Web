package com.example.miautomotriz;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.miautomotriz.db.AutomotrizDbHelper;

public class HistorialServiciosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historial_servicios);

        TextView tvHistorial = findViewById(R.id.tvHistorial);
        AutomotrizDbHelper dbHelper = new AutomotrizDbHelper(this);

        Cursor cursor = dbHelper.obtenerHistorialOrdenes();

        if (cursor.getCount() == 0) {
            tvHistorial.setText("Aún no hay historial.");
            return;
        }

        StringBuilder sb = new StringBuilder();

        while (cursor.moveToNext()) {
            sb.append("Fecha: ").append(cursor.getString(cursor.getColumnIndexOrThrow("fecha"))).append("\n");
            sb.append("Vehículo: ")
                    .append(cursor.getString(cursor.getColumnIndexOrThrow("modelo")))
                    .append(" - ")
                    .append(cursor.getString(cursor.getColumnIndexOrThrow("matricula")))
                    .append("\n");
            sb.append("Mecánico: ")
                    .append(cursor.getString(cursor.getColumnIndexOrThrow("mecanico")))
                    .append("\n");
            sb.append(cursor.getString(cursor.getColumnIndexOrThrow("servicios"))).append("\n");
            sb.append("Total: $")
                    .append(cursor.getInt(cursor.getColumnIndexOrThrow("total")))
                    .append("\n");
            sb.append("-----------------------------\n\n");
        }

        cursor.close();
        tvHistorial.setText(sb.toString());
    }
}
