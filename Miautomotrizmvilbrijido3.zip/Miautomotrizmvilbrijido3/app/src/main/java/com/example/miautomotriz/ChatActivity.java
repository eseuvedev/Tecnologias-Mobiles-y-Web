package com.example.miautomotriz;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miautomotriz.db.AutomotrizDbHelper;

import java.util.List;

public class ChatActivity extends AppCompatActivity {

    private AutomotrizDbHelper dbHelper;
    private ChatAdapter adapter;
    private boolean esAdmin = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        esAdmin = getIntent().getBooleanExtra("ES_ADMIN", false);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(esAdmin ? "Chat (Admin)" : "Chat Directo");
        }

        dbHelper = new AutomotrizDbHelper(this);

        RecyclerView recycler = findViewById(R.id.recyclerChat);
        EditText etMensaje = findViewById(R.id.etMensaje);
        Button btnEnviar = findViewById(R.id.btnEnviar);

        recycler.setLayoutManager(new LinearLayoutManager(this));

        List<Mensaje> mensajes = dbHelper.obtenerMensajes();
        adapter = new ChatAdapter(mensajes);
        recycler.setAdapter(adapter);

        // ir al final al abrir
        if (adapter.getItemCount() > 0) {
            recycler.scrollToPosition(adapter.getItemCount() - 1);
        }

        btnEnviar.setOnClickListener(v -> {
            String texto = etMensaje.getText().toString().trim();
            if (texto.isEmpty()) {
                Toast.makeText(this, "Escribe un mensaje", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean esCliente = !esAdmin; // admin=false => cliente=true

            dbHelper.insertarMensaje(texto, esCliente);

            adapter.actualizar(dbHelper.obtenerMensajes());
            etMensaje.setText("");

            // ir al final después de enviar
            if (adapter.getItemCount() > 0) {
                recycler.scrollToPosition(adapter.getItemCount() - 1);
            }
        });
    }
}
