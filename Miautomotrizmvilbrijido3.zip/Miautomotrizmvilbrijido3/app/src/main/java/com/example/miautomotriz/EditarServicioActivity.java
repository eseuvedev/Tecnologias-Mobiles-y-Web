package com.example.miautomotriz;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.miautomotriz.db.AutomotrizDbHelper;

public class EditarServicioActivity extends AppCompatActivity {

    public static final String EXTRA_SERVICIO_ID = "EXTRA_SERVICIO_ID";

    private EditText etNombre, etDescripcion, etPrecio;
    private Button btnGuardar;
    private TextView tvTitulo;

    private AutomotrizDbHelper dbHelper;
    private Servicio servicioActual;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_servicio);

        dbHelper = new AutomotrizDbHelper(this);

        etNombre = findViewById(R.id.etNombreServicio);
        etDescripcion = findViewById(R.id.etDescripcionServicio);
        etPrecio = findViewById(R.id.etPrecioServicio);
        btnGuardar = findViewById(R.id.btnGuardarServicio);

        tvTitulo = findViewById(R.id.tvTituloFormulario);
        if (tvTitulo != null) tvTitulo.setText("Editar Servicio");
        btnGuardar.setText("Actualizar Servicio");

        int servicioId = getIntent().getIntExtra(EXTRA_SERVICIO_ID, -1);
        if (servicioId == -1) {
            Toast.makeText(this, "Error: ID de servicio no válido", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }


        servicioActual = dbHelper.obtenerServicioPorId(servicioId);
        if (servicioActual == null) {
            Toast.makeText(this, "Error: Servicio no encontrado", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        etNombre.setText(servicioActual.getNombre());
        etDescripcion.setText(servicioActual.getDescripcion());
        etPrecio.setText(servicioActual.getPrecio());

        btnGuardar.setOnClickListener(v -> actualizarServicio());
    }

    private void actualizarServicio() {
        String nombre = etNombre.getText().toString().trim();
        String descripcion = etDescripcion.getText().toString().trim();
        String precio = etPrecio.getText().toString().trim();

        if (nombre.isEmpty() || descripcion.isEmpty() || precio.isEmpty()) {
            Toast.makeText(this, "Por favor, llena todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        Servicio servicioActualizado = new Servicio(nombre, descripcion, precio);

        // Mantener el ID original (IMPORTANTE)
        // Si tu clase Servicio tiene setId():
        // servicioActualizado.setId(servicioActual.getId());

        // Si NO tienes setId, crea el objeto con el id directamente:
        // Servicio servicioActualizado = new Servicio(servicioActual.getId(), nombre, descripcion, precio);

        int filasAfectadas = dbHelper.actualizarServicio(
                servicioActual.getId(),
                nombre,
                descripcion,
                precio
        );


        if (filasAfectadas > 0) {
            Toast.makeText(this, "Servicio actualizado", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Error al actualizar", Toast.LENGTH_SHORT).show();
        }
    }
}
