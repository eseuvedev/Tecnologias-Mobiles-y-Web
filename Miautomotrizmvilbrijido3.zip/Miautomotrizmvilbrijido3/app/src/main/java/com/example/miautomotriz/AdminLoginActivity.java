package com.example.miautomotriz;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdminLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        EditText edtUser = findViewById(R.id.edtAdminUser);
        EditText edtPass = findViewById(R.id.edtAdminPass);
        Button btnLogin = findViewById(R.id.btnAdminLogin);

        btnLogin.setOnClickListener(v -> {
            String user = edtUser.getText().toString().trim();
            String pass = edtPass.getText().toString().trim();

            // Login admin "dummy" por ahora
            if (user.equals("admin") && pass.equals("admin123")) {
                startActivity(new Intent(this, AdminMenuActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Credenciales de admin incorrectas", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
