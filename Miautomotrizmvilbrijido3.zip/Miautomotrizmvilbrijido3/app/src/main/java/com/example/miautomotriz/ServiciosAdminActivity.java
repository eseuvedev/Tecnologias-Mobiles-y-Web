package com.example.miautomotriz;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.Button;
import android.content.Intent;


import com.example.miautomotriz.db.AutomotrizDbHelper;

import java.util.List;

public class ServiciosAdminActivity extends AppCompatActivity {

    private RecyclerView recyclerServicios;
    private AutomotrizDbHelper dbHelper;
    private ServicioAdminAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_servicios_admin);

        // RecyclerView
        recyclerServicios = findViewById(R.id.recyclerServicios);
        recyclerServicios.setLayoutManager(new LinearLayoutManager(this));

        // DbHelper
        dbHelper = new AutomotrizDbHelper(this);

        // BOTÓN AGREGAR SERVICIO
        Button btnIrAgregar = findViewById(R.id.btnIrAgregarServicio);
        btnIrAgregar.setOnClickListener(v ->
                startActivity(new Intent(this, AgregarServicioActivity.class))
        );
    }

    @Override
    protected void onResume() {
        super.onResume();

        List<Servicio> listaServicios = dbHelper.obtenerTodosLosServicios();
        adapter = new ServicioAdminAdapter(this, listaServicios, dbHelper);
        recyclerServicios.setAdapter(adapter);
    }


}

