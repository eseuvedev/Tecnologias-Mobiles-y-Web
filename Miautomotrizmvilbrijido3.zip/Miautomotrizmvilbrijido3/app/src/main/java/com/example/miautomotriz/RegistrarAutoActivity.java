package com.example.miautomotriz;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class RegistrarAutoActivity extends AppCompatActivity {

    // ArrayList para guardar modelos registrados (por ahora en memoria)
    public static ArrayList<String> modelosRegistrados = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrar_auto);

        EditText edtMatricula = findViewById(R.id.edtMatricula);
        EditText edtModelo = findViewById(R.id.edtModelo);
        Spinner spTransmision = findViewById(R.id.spTransmision);
        Spinner spCombustible = findViewById(R.id.spCombustible);
        Button btnRegistrar = findViewById(R.id.btnRegistrarContinuar);

        // Spinner Transmisión
        ArrayList<String> listaTransmision = new ArrayList<>();
        listaTransmision.add("Seleccionar");
        listaTransmision.add("Manual");
        listaTransmision.add("Automática");
        listaTransmision.add("CVT");

        ArrayAdapter<String> adapterTrans = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, listaTransmision);
        spTransmision.setAdapter(adapterTrans);

        // Spinner Combustible
        ArrayList<String> listaCombustible = new ArrayList<>();
        listaCombustible.add("Seleccionar");
        listaCombustible.add("Bencina");
        listaCombustible.add("Diésel");
        listaCombustible.add("Eléctrico");
        listaCombustible.add("Híbrido");

        ArrayAdapter<String> adapterComb = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_dropdown_item, listaCombustible);
        spCombustible.setAdapter(adapterComb);

        btnRegistrar.setOnClickListener(v -> {
            String matricula = edtMatricula.getText().toString().trim();
            String modelo = edtModelo.getText().toString().trim();
            String transmision = spTransmision.getSelectedItem().toString();
            String combustible = spCombustible.getSelectedItem().toString();

            // Validaciones simples
            if (TextUtils.isEmpty(matricula)) {
                edtMatricula.setError("Ingresa la matrícula");
                edtMatricula.requestFocus();
                return;
            }
            if (TextUtils.isEmpty(modelo)) {
                edtModelo.setError("Ingresa el modelo");
                edtModelo.requestFocus();
                return;
            }
            if (transmision.equals("Seleccionar")) {
                Toast.makeText(this, "Selecciona transmisión", Toast.LENGTH_SHORT).show();
                return;
            }
            if (combustible.equals("Seleccionar")) {
                Toast.makeText(this, "Selecciona combustible", Toast.LENGTH_SHORT).show();
                return;
            }

            // Guardar modelo en ArrayList (opcional)
            modelosRegistrados.add(modelo);

            //  GUARDAR COMO ORDEN ACTUAL
            getSharedPreferences("orden_actual", MODE_PRIVATE)
                    .edit()
                    .putString("matricula", matricula)
                    .putString("modelo", modelo)
                    .putString("transmision", transmision)
                    .putString("combustible", combustible)
                    .apply();

            Toast.makeText(this,
                    "Auto registrado: " + matricula + " - " + modelo,
                    Toast.LENGTH_SHORT).show();

            Intent i = new Intent(this, SeleccionarServiciosActivity.class);
            i.putExtra("matricula", matricula);
            i.putExtra("modelo", modelo);
            startActivity(i);
            finish();

        });
    }
}
