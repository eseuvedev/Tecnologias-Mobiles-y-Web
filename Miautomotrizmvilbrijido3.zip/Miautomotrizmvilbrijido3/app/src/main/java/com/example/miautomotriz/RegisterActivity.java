package com.example.miautomotriz;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    private EditText edtNombre, edtApellido, edtTelefono, edtCorreo;
    private Button btnAceptar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        edtNombre = findViewById(R.id.edtNombre);
        edtApellido = findViewById(R.id.edtApellido);
        edtTelefono = findViewById(R.id.edtTelefono);
        edtCorreo = findViewById(R.id.edtCorreoRegistro);
        btnAceptar = findViewById(R.id.btnAceptarRegistro);

        btnAceptar.setOnClickListener(v -> {
            String nombre = edtNombre.getText().toString().trim();
            String apellido = edtApellido.getText().toString().trim();
            String telefono = edtTelefono.getText().toString().trim();
            String correo = edtCorreo.getText().toString().trim();

            if (TextUtils.isEmpty(nombre)) {
                edtNombre.setError("Ingresa tu nombre");
                edtNombre.requestFocus();
                return;
            }

            if (TextUtils.isEmpty(apellido)) {
                edtApellido.setError("Ingresa tu apellido");
                edtApellido.requestFocus();
                return;
            }

            if (TextUtils.isEmpty(telefono)) {
                edtTelefono.setError("Ingresa tu teléfono");
                edtTelefono.requestFocus();
                return;
            }

            if (TextUtils.isEmpty(correo) || !Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
                edtCorreo.setError("Correo inválido");
                edtCorreo.requestFocus();
                return;
            }

            // Por ahora solo validamos y volvemos al login
            Toast.makeText(this, "Registro completado", Toast.LENGTH_SHORT).show();
            finish(); // vuelve a LoginActivity
        });
    }
}
