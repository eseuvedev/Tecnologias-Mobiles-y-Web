package com.example.miautomotriz;

public class Servicio {
    private int id;
    private String nombre;
    private String descripcion;
    private String precio;

    // Para cuando lees desde DB (con id)
    public Servicio(int id, String nombre, String descripcion, String precio) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    // Para cuando insertas nuevo (sin id)
    public Servicio(String nombre, String descripcion, String precio) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }
    public String getPrecio() { return precio; }
}
