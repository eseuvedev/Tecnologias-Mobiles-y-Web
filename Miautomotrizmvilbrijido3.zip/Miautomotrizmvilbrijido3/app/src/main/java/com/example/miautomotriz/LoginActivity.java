package com.example.miautomotriz;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText edtCorreo, edtPassword;
    private Button btnLogin, btnAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Vincular vistas
        edtCorreo = findViewById(R.id.edtCorreo);
        edtPassword = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnAdmin = findViewById(R.id.btnAdmin);

        // Botón Admin -> abre pantalla de login admin
        btnAdmin.setOnClickListener(v -> {
            Intent i = new Intent(LoginActivity.this, AdminLoginActivity.class);
            startActivity(i);
        });

        // Botón Registrarse -> abre pantalla de registro
        Button btnRegistro = findViewById(R.id.btnRegistro);

        btnRegistro.setOnClickListener(v -> {
            startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
        });


        // Botón Login cliente
        btnLogin.setOnClickListener(v -> {
            String correo = edtCorreo.getText() != null ? edtCorreo.getText().toString().trim() : "";
            String pass = edtPassword.getText() != null ? edtPassword.getText().toString().trim() : "";

            // Validaciones
            if (TextUtils.isEmpty(correo)) {
                edtCorreo.setError("Ingresa tu correo");
                edtCorreo.requestFocus();
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
                edtCorreo.setError("Correo inválido");
                edtCorreo.requestFocus();
                return;
            }

            if (TextUtils.isEmpty(pass)) {
                edtPassword.setError("Ingresa tu contraseña");
                edtPassword.requestFocus();
                return;
            }

            if (pass.length() < 4) {
                edtPassword.setError("Mínimo 4 caracteres");
                edtPassword.requestFocus();
                return;
            }

            // Login "dummy" (temporal)
            // Cambia esto cuando conectes Firebase o tu API PHP/MySQL
            if (correo.equals("cliente@miasutomotriz.cl") && pass.equals("1234")) {
                Toast.makeText(this, "Bienvenido", Toast.LENGTH_SHORT).show();

                Intent i = new Intent(LoginActivity.this, HomeActivity.class);
                startActivity(i);
                finish(); // para que no vuelva al login con back
            } else {
                Toast.makeText(this, "Credenciales incorrectas", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
