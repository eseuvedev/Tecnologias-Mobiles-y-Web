package com.example.miautomotriz.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.miautomotriz.Mensaje;


import com.example.miautomotriz.Servicio;

import java.util.ArrayList;
import java.util.List;


public class AutomotrizDbHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "miautomotriz.db";
    private static final int DB_VERSION = 4;

    public static final String TABLE_SERVICIOS = "servicios";
    public static final String COL_ID = "id";
    public static final String COL_NOMBRE = "nombre";
    public static final String COL_DESCRIPCION = "descripcion";
    public static final String COL_PRECIO = "precio";
    private static final String TABLE_ORDENES = "ordenes";
    private static final String TABLE_AUTOS = "autos";


    public AutomotrizDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_SERVICIOS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NOMBRE + " TEXT NOT NULL, " +
                COL_DESCRIPCION + " TEXT, " +
                COL_PRECIO + " INTEGER NOT NULL" +
                ")";
        db.execSQL(createTable);

        // Servicios iniciales
        insertarServicioInicial(db, "Cambio de aceite",
                "Incluye cambio de aceite y revisión básica", 25000);
        insertarServicioInicial(db, "Diagnóstico computarizado",
                "Escaneo completo del vehículo", 30000);
        insertarServicioInicial(db, "Mantenimiento de filtros",
                "Revisión y cambio de filtros", 18000);
        insertarServicioInicial(db, "Mantenimiento de neumáticos",
                "Rotación y revisión de neumáticos", 40000);

        String createOrdenes = "CREATE TABLE " + TABLE_ORDENES + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "matricula TEXT," +
                "modelo TEXT," +
                "mecanico TEXT," +
                "servicios TEXT," +
                "total INTEGER," +
                "fecha TEXT" +
                ")";
        db.execSQL(createOrdenes);

        db.execSQL("CREATE TABLE chat (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "mensaje TEXT," +
                "esCliente INTEGER)");

        db.execSQL("CREATE TABLE " + TABLE_AUTOS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "matricula TEXT," +
                "modelo TEXT," +
                "transmision TEXT," +
                "combustible TEXT" +
                ")");


    }

    private void insertarServicioInicial(SQLiteDatabase db,
                                         String nombre,
                                         String descripcion,
                                         int precio) {
        ContentValues values = new ContentValues();
        values.put(COL_NOMBRE, nombre);
        values.put(COL_DESCRIPCION, descripcion);
        values.put(COL_PRECIO, precio);
        db.insert(TABLE_SERVICIOS, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SERVICIOS);
        onCreate(db);

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDENES);
        onCreate(db);

    }

    // =========================
    // INSERTAR SERVICIO
    // =========================
    public long insertarServicio(String nombre, String descripcion, int precio) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NOMBRE, nombre);
        values.put(COL_DESCRIPCION, descripcion);
        values.put(COL_PRECIO, precio);
        long id = db.insert(TABLE_SERVICIOS, null, values);
        db.close();
        return id;
    }

    // =========================
    // OBTENER TODOS LOS SERVICIOS
    // =========================
    public List<Servicio> obtenerTodosLosServicios() {
        List<Servicio> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT id, nombre, descripcion, precio FROM " + TABLE_SERVICIOS,
                null
        );

        if (cursor.moveToFirst()) {
            do {
                Servicio s = new Servicio(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        String.valueOf(cursor.getInt(3))
                );
                lista.add(s);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return lista;
    }

    // =========================
    // OBTENER SERVICIO POR ID
    // =========================
    public Servicio obtenerServicioPorId(int id) {
        SQLiteDatabase db = getReadableDatabase();
        Servicio servicio = null;

        Cursor cursor = db.rawQuery(
                "SELECT id, nombre, descripcion, precio FROM " + TABLE_SERVICIOS + " WHERE id = ?",
                new String[]{String.valueOf(id)}
        );

        if (cursor.moveToFirst()) {
            servicio = new Servicio(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2),
                    String.valueOf(cursor.getInt(3))
            );
        }

        cursor.close();
        db.close();
        return servicio;
    }

    // =========================
    // ACTUALIZAR SERVICIO
    // =========================
    public int actualizarServicio(int id, String nombre, String descripcion, String precio) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NOMBRE, nombre);
        values.put(COL_DESCRIPCION, descripcion);
        values.put(COL_PRECIO, Integer.parseInt(precio));

        int filas = db.update(
                TABLE_SERVICIOS,
                values,
                "id = ?",
                new String[]{String.valueOf(id)}
        );

        db.close();
        return filas;
    }

    // =========================
    // ELIMINAR SERVICIO
    // =========================
    public int eliminarServicio(int id) {
        SQLiteDatabase db = getWritableDatabase();
        int filas = db.delete(TABLE_SERVICIOS, "id = ?", new String[]{String.valueOf(id)});
        db.close();
        return filas;
    }

    public List<Servicio> obtenerServiciosPorIds(List<Integer> ids) {
        List<Servicio> lista = new ArrayList<>();
        if (ids == null || ids.isEmpty()) return lista;

        SQLiteDatabase db = getReadableDatabase();

        StringBuilder placeholders = new StringBuilder();
        String[] args = new String[ids.size()];

        for (int i = 0; i < ids.size(); i++) {
            placeholders.append("?");
            if (i < ids.size() - 1) placeholders.append(",");
            args[i] = String.valueOf(ids.get(i));
        }

        Cursor cursor = db.rawQuery(
                "SELECT id, nombre, descripcion, precio FROM servicios WHERE id IN (" + placeholders + ")",
                args
        );

        if (cursor.moveToFirst()) {
            do {
                lista.add(new Servicio(
                        cursor.getInt(0),
                        cursor.getString(1),
                        cursor.getString(2),
                        String.valueOf(cursor.getInt(3))
                ));
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return lista;
    }
    public void insertarOrden(String matricula, String modelo, String mecanico,
                              String servicios, int total, String fecha) {

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("matricula", matricula);
        values.put("modelo", modelo);
        values.put("mecanico", mecanico);
        values.put("servicios", servicios);
        values.put("total", total);
        values.put("fecha", fecha);

        db.insert(TABLE_ORDENES, null, values);
        db.close();
    }
    public Cursor obtenerHistorialOrdenes() {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery(
                "SELECT * FROM " + TABLE_ORDENES + " ORDER BY id DESC",
                null
        );
    }
    public void insertarMensaje(String mensaje, boolean esCliente) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("mensaje", mensaje);
        cv.put("esCliente", esCliente ? 1 : 0);
        db.insert("chat", null, cv);
    }

    public List<Mensaje> obtenerMensajes() {
        List<Mensaje> lista = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM chat", null);

        while (c.moveToNext()) {
            lista.add(new Mensaje(
                    c.getString(1),
                    c.getInt(2) == 1
            ));
        }
        c.close();
        return lista;
    }


}
