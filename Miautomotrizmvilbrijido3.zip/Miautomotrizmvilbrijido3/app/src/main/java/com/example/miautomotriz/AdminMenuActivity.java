package com.example.miautomotriz;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class AdminMenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_menu);

        Button btnServicios = findViewById(R.id.btnServicios);

        btnServicios.setOnClickListener(v ->
                startActivity(new Intent(this, ServiciosAdminActivity.class))
        );

        Button btnChatAdmin = findViewById(R.id.btnChatAdmin);

        btnChatAdmin.setOnClickListener(v -> {
            Intent i = new Intent(this, ChatActivity.class);
            i.putExtra("ES_ADMIN", true);
            startActivity(i);
        });


    }
}
