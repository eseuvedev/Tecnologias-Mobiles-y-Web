package com.example.miautomotriz;

public class Mensaje {

    private String texto;
    private boolean esCliente;

    public Mensaje(String texto, boolean esCliente) {
        this.texto = texto;
        this.esCliente = esCliente;
    }

    public String getTexto() {
        return texto;
    }

    public boolean isEsCliente() {
        return esCliente;
    }
}
