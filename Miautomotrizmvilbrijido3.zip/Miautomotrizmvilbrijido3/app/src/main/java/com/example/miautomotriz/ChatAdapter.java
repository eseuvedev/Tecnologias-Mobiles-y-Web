package com.example.miautomotriz;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.ChatViewHolder> {

    private List<Mensaje> mensajes;

    public ChatAdapter(List<Mensaje> mensajes) {
        this.mensajes = mensajes;
    }
    public void actualizar(List<Mensaje> nuevosMensajes) {
        this.mensajes = nuevosMensajes;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ChatViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_mensaje, parent, false);
        return new ChatViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChatViewHolder holder, int position) {
        Mensaje mensaje = mensajes.get(position);
        holder.txtMensaje.setText(mensaje.getTexto());
    }

    @Override
    public int getItemCount() {
        return mensajes.size();
    }

    static class ChatViewHolder extends RecyclerView.ViewHolder {
        TextView txtMensaje;

        ChatViewHolder(@NonNull View itemView) {
            super(itemView);
            txtMensaje = itemView.findViewById(R.id.txtMensaje);
        }
    }
}
