package com.example.miautomotriz;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miautomotriz.db.AutomotrizDbHelper;

import java.util.ArrayList;
import java.util.List;

public class SeleccionarServiciosActivity extends AppCompatActivity {

    private AutomotrizDbHelper dbHelper;
    private ServiciosSeleccionAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seleccionar_servicios);

        RecyclerView recycler = findViewById(R.id.recyclerServiciosSeleccion);
        Button btnConfirmar = findViewById(R.id.btnConfirmarServicios);

        recycler.setLayoutManager(new LinearLayoutManager(this));
        dbHelper = new AutomotrizDbHelper(this);

        List<Servicio> lista = dbHelper.obtenerTodosLosServicios();
        adapter = new ServiciosSeleccionAdapter(lista);
        recycler.setAdapter(adapter);

        // Recibimos del registro del auto
        String matricula = getIntent().getStringExtra("matricula");
        String modelo = getIntent().getStringExtra("modelo");

        btnConfirmar.setOnClickListener(v -> {
            ArrayList<Integer> ids = new ArrayList<>(adapter.getSeleccionadosIds());

            if (ids.isEmpty()) {
                Toast.makeText(this, "Selecciona al menos un servicio", Toast.LENGTH_SHORT).show();
                return;
            }

            Toast.makeText(this, "Servicios seleccionados: " + ids.size(), Toast.LENGTH_SHORT).show();

            Intent i = new Intent(this, ElegirMecanicoActivity.class);
            i.putIntegerArrayListExtra("servicios_ids", ids); // <-- ESTA KEY se mantiene
            i.putExtra("matricula", matricula);
            i.putExtra("modelo", modelo);
            startActivity(i);
            finish();
        });
    }
}
