package com.example.miautomotriz;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.navigation.NavigationView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class HomeActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        drawerLayout = findViewById(R.id.drawerLayout);
        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        NavigationView navigationView = findViewById(R.id.navigationView);

        // Toolbar como ActionBar
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("");


        // Botón hamburguesa
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawerLayout, toolbar,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close
        );
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        // Botón principal en pantalla
        Button btnRegistrarAuto = findViewById(R.id.btnRegistrarAuto);
        btnRegistrarAuto.setOnClickListener(v ->
                startActivity(new Intent(this, RegistrarAutoActivity.class))
        );

        // Clicks del menú lateral
        navigationView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();

            if (id == R.id.nav_registrar_auto) {
                startActivity(new Intent(this, RegistrarAutoActivity.class));
            }
            if (id == R.id.nav_precios) {
                startActivity(new Intent(this, PreciosActivity.class));
            } else if (id == R.id.nav_orden) {
                startActivity(new Intent(this, OrdenActualActivity.class));
            } else if (id == R.id.nav_historial) {
                startActivity(new Intent(this, HistorialServiciosActivity.class));
            } else if (id == R.id.nav_logout) {
                Intent i = new Intent(this, LoginActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                finish();}

            drawerLayout.closeDrawers();
            return true;
        });

        // Bloquear botón atrás en Home (tu caso)
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // No hacer nada
            }
        });

        FloatingActionButton fabChat = findViewById(R.id.fabChat);

        fabChat.setOnClickListener(v -> {
            startActivity(new Intent(this, ChatActivity.class));
        });

    }
}
