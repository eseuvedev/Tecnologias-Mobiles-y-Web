package com.example.miautomotriz;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.FileProvider;

import com.example.miautomotriz.db.AutomotrizDbHelper;
import com.google.android.material.appbar.MaterialToolbar;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

public class CotizacionActivity extends AppCompatActivity {

    private static final String CHANNEL_ID = "miautomotriz_channel";
    private AutomotrizDbHelper dbHelper;
    private String mecanicoSeleccionado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cotizacion);

        TextView tvAuto = findViewById(R.id.tvAuto);
        TextView tvMecanico = findViewById(R.id.tvMecanico);
        TextView tvServicios = findViewById(R.id.tvServicios);
        TextView tvTotal = findViewById(R.id.tvTotal);
        Button btnConfirmar = findViewById(R.id.btnConfirmar);
        Button btnCompartir = findViewById(R.id.btnCompartir);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("");
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        String matricula = getIntent().getStringExtra("matricula");
        String modelo = getIntent().getStringExtra("modelo");
        mecanicoSeleccionado = getIntent().getStringExtra("mecanico");

        ArrayList<Integer> ids = getIntent().getIntegerArrayListExtra("servicios_ids");
        if (ids == null) ids = new ArrayList<>();

        tvAuto.setText("Vehículo: " + modelo + " - Matrícula " + matricula);
        tvMecanico.setText("Mecánico: " + (mecanicoSeleccionado != null ? mecanicoSeleccionado : "No asignado"));

        dbHelper = new AutomotrizDbHelper(this);
        List<Servicio> servicios = dbHelper.obtenerServiciosPorIds(ids);

        int total = 0;
        StringBuilder sb = new StringBuilder("Servicios:\n");

        for (Servicio s : servicios) {
            sb.append("- ").append(s.getNombre())
                    .append(" ($").append(s.getPrecio()).append(")\n");
            try { total += Integer.parseInt(s.getPrecio()); } catch (Exception ignored) {}
        }

        final int totalFinal = total;
        final String serviciosTextoFinal = sb.toString();

        tvServicios.setText(serviciosTextoFinal);
        tvTotal.setText("Total: $" + totalFinal);

        crearCanalNotificacion();

        btnConfirmar.setOnClickListener(v -> {
            guardarOrdenActual(matricula, modelo, mecanicoSeleccionado, serviciosTextoFinal, totalFinal);
            enviarNotificacionVehiculoListo();
            Intent i = new Intent(this, HomeActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
        });

        btnCompartir.setOnClickListener(v -> {
            String contenido = "COTIZACIÓN\n\n"
                    + "Vehículo: " + modelo + " - " + matricula + "\n"
                    + "Mecánico: " + mecanicoSeleccionado + "\n\n"
                    + serviciosTextoFinal + "\n"
                    + "TOTAL: $" + totalFinal;

            File pdf = crearPdfCotizacion(contenido);
            if (pdf != null) compartirPdf(pdf);
            else Toast.makeText(this, "No se pudo generar el PDF", Toast.LENGTH_SHORT).show();
        });
    }

    private void guardarOrdenActual(String matricula, String modelo, String mecanico, String serviciosTexto, int total) {
        getSharedPreferences("orden_actual", MODE_PRIVATE)
                .edit()
                .putBoolean("existe", true)
                .putString("matricula", matricula)
                .putString("modelo", modelo)
                .putString("mecanico", mecanico)
                .putString("servicios", serviciosTexto)
                .putInt("total", total)
                .apply();
    }

    private void crearCanalNotificacion() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "MiAutomotriz", NotificationManager.IMPORTANCE_DEFAULT);
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void enviarNotificacionVehiculoListo() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
            return;
        }

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("MiAutomotriz")
                .setContentText("Su vehículo está listo")
                .setAutoCancel(true);

        NotificationManagerCompat.from(this).notify(1, builder.build());
    }

    private File crearPdfCotizacion(String texto) {
        try {
            PdfDocument pdfDocument = new PdfDocument();
            Paint paint = new Paint();
            PdfDocument.PageInfo pageInfo =
                    new PdfDocument.PageInfo.Builder(595, 842, 1).create();

            PdfDocument.Page page = pdfDocument.startPage(pageInfo);
            Canvas canvas = page.getCanvas();

            int x = 40, y = 60;
            paint.setTextSize(14);

            for (String linea : texto.split("\n")) {
                canvas.drawText(linea, x, y, paint);
                y += 22;
            }

            pdfDocument.finishPage(page);

            File file = new File(getCacheDir(), "cotizacion_miautomotriz.pdf");
            FileOutputStream fos = new FileOutputStream(file);
            pdfDocument.writeTo(fos);

            fos.close();
            pdfDocument.close();
            return file;

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void compartirPdf(File file) {
        Uri uri = FileProvider.getUriForFile(
                this, getPackageName() + ".fileprovider", file);

        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_STREAM, uri);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivity(Intent.createChooser(intent, "Compartir cotización"));
    }
}
