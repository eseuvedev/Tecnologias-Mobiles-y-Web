package com.example.miautomotriz;

import com.example.miautomotriz.db.AutomotrizDbHelper;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// Importamos el DbHelper

public class AgregarServicioActivity extends AppCompatActivity {

    // Vistas
    private EditText etNombre, etDescripcion, etPrecio;
    private Button btnGuardar;

    // Base de datos
    private AutomotrizDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_servicio);

        // Inicializamos el DbHelper
        dbHelper = new AutomotrizDbHelper(this);

        // Enlazamos las vistas
        etNombre = findViewById(R.id.etNombreServicio);
        etDescripcion = findViewById(R.id.etDescripcionServicio);
        etPrecio = findViewById(R.id.etPrecioServicio);
        btnGuardar = findViewById(R.id.btnGuardarServicio);

        // Ponemos el listener al botón de guardar
        btnGuardar.setOnClickListener(v -> guardarServicio());
    }

    private void guardarServicio() {
        String nombre = etNombre.getText().toString().trim();
        String descripcion = etDescripcion.getText().toString().trim();
        String precio = etPrecio.getText().toString().trim();

        if (nombre.isEmpty() || descripcion.isEmpty() || precio.isEmpty()) {
            Toast.makeText(this, "Por favor, llena todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }


        Servicio nuevoServicio = new Servicio(nombre, descripcion, precio);

        long id = dbHelper.insertarServicio(    nuevoServicio.getNombre(),
                nuevoServicio.getDescripcion(),
                Integer.parseInt(nuevoServicio.getPrecio())
        );

        if (id != -1) {
            Toast.makeText(this, "Servicio guardado", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Error al guardar el servicio", Toast.LENGTH_SHORT).show();
        }
    }
}
