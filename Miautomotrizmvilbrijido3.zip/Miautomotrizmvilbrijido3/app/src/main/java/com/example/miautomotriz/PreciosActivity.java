package com.example.miautomotriz;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miautomotriz.db.AutomotrizDbHelper;
import com.google.android.material.appbar.MaterialToolbar;

import java.util.List;

public class PreciosActivity extends AppCompatActivity {

    private RecyclerView recyclerPrecios;
    private AutomotrizDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_precios);

        recyclerPrecios = findViewById(R.id.recyclerPrecios);
        recyclerPrecios.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new AutomotrizDbHelper(this);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getSupportActionBar().setDisplayUseLogoEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("");

    }

    @Override
    protected void onResume() {
        super.onResume();
        List<Servicio> lista = dbHelper.obtenerTodosLosServicios(); // <-- misma tabla servicios
        recyclerPrecios.setAdapter(new PreciosAdapter(lista));
    }
}
