package com.example.miautomotriz;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.HashSet;
import java.util.List;

public class ServiciosSeleccionAdapter extends RecyclerView.Adapter<ServiciosSeleccionAdapter.ViewHolder> {

    private final List<Servicio> lista;
    private final HashSet<Integer> seleccionadosIds = new HashSet<>();

    public ServiciosSeleccionAdapter(List<Servicio> lista) {
        this.lista = lista;
    }

    public HashSet<Integer> getSeleccionadosIds() {
        return seleccionadosIds;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_servicio_seleccion, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Servicio s = lista.get(position);

        holder.chkServicio.setText(s.getNombre());
        holder.tvDescripcion.setText(s.getDescripcion());
        holder.tvPrecio.setText("$" + s.getPrecio());

        // Evitar problemas por reciclaje de vistas
        holder.chkServicio.setOnCheckedChangeListener(null);
        holder.chkServicio.setChecked(seleccionadosIds.contains(s.getId()));

        holder.chkServicio.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                seleccionadosIds.add(s.getId());
            } else {
                seleccionadosIds.remove(s.getId());
            }
        });

        // Si tocan el item, también togglear
        holder.itemView.setOnClickListener(v -> holder.chkServicio.performClick());
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        CheckBox chkServicio;
        TextView tvDescripcion, tvPrecio;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            chkServicio = itemView.findViewById(R.id.chkServicio);
            tvDescripcion = itemView.findViewById(R.id.tvDescripcion);
            tvPrecio = itemView.findViewById(R.id.tvPrecio);
        }
    }
}
