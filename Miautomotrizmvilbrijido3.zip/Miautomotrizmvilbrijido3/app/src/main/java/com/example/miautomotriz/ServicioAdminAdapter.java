package com.example.miautomotriz;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miautomotriz.db.AutomotrizDbHelper;

import java.util.List;

public class ServicioAdminAdapter extends RecyclerView.Adapter<ServicioAdminAdapter.ViewHolder> {

    private Context context;
    private List<Servicio> lista;
    private AutomotrizDbHelper dbHelper;

    public ServicioAdminAdapter(Context context, List<Servicio> lista, AutomotrizDbHelper dbHelper) {
        this.context = context;
        this.lista = lista;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context)
                .inflate(R.layout.item_servicio_admin, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Servicio s = lista.get(position);

        holder.tvNombre.setText(s.getNombre());
        holder.tvDescripcion.setText(s.getDescripcion());
        holder.tvPrecio.setText(s.getPrecio());

        holder.btnEditar.setOnClickListener(v -> {
            Intent i = new Intent(context, EditarServicioActivity.class);
            i.putExtra(EditarServicioActivity.EXTRA_SERVICIO_ID, s.getId());
            context.startActivity(i);
        });

        holder.btnEliminar.setOnClickListener(v -> {
            dbHelper.eliminarServicio(s.getId());
            Toast.makeText(context, "Servicio eliminado", Toast.LENGTH_SHORT).show();
            lista.remove(position);
            notifyItemRemoved(position);
        });
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre, tvDescripcion, tvPrecio;
        Button btnEditar, btnEliminar;

        ViewHolder(View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvNombre);
            tvDescripcion = itemView.findViewById(R.id.tvDescripcion);
            tvPrecio = itemView.findViewById(R.id.tvPrecio);
            btnEditar = itemView.findViewById(R.id.btnEditar);
            btnEliminar = itemView.findViewById(R.id.btnEliminar);
        }
    }
}
