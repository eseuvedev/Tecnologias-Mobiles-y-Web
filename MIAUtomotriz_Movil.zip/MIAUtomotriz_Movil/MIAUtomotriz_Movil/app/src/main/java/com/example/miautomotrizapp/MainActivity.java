package com.example.miautomotrizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

// IMPORTS PARA VOLLEY Y JSON
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    // Usamos la constante definida en LoginActivity
    public static final String EXTRA_ADMIN = "com.example.miautomotrizapp.EXTRA_ADMIN";
    public static final String EXTRA_VEHICULO = "com.miautomotriz.VEHICULO";

    private EditText etMatricula;
    private EditText etModelo;
    private Spinner spinnerTransmision;
    private Spinner spinnerCombustible;

    // Variable para el nombre del administrador
    private String nombreAdministrador;

    // 1. LA URL DE NGROK (Apuntando a tu archivo PHP)
    private static final String URL_API = "https://leisurely-anthroposophic-shara.ngrok-free.dev/api_reparaciones.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Recuperar el nombre del administrador desde el Intent
        if (getIntent().hasExtra(EXTRA_ADMIN)) {
            nombreAdministrador = getIntent().getStringExtra(EXTRA_ADMIN);
            Toast.makeText(this, "Bienvenido: " + nombreAdministrador, Toast.LENGTH_LONG).show();
        } else {
            nombreAdministrador = "Admin Desconocido";
        }

        // Inicializar las vistas
        etMatricula = findViewById(R.id.et_matricula);
        etModelo = findViewById(R.id.et_modelo);
        spinnerTransmision = findViewById(R.id.spinner_transmision);
        spinnerCombustible = findViewById(R.id.spinner_combustible);

        // Probar la API al entrar a la pantalla
        cargarDatos();
    }

    /**
     * Método llamado al pulsar el botón "Registrar y Continuar".
     */
    public void registrarVehiculo(View view) {
        String matricula = etMatricula.getText().toString().trim();
        String modelo = etModelo.getText().toString().trim();
        String transmision = spinnerTransmision.getSelectedItem().toString();
        String combustible = spinnerCombustible.getSelectedItem().toString();

        if (matricula.isEmpty() || modelo.isEmpty() ||
                transmision.startsWith("Seleccionar") || combustible.startsWith("Seleccionar")) {
            Toast.makeText(this, "Por favor, completa todos los campos del vehículo.", Toast.LENGTH_LONG).show();
            return;
        }

        Vehiculo vehiculoRegistrado = new Vehiculo(matricula, modelo, transmision, combustible);

        // Crear Intent para ir a MenuActivity
        Intent intent = new Intent(this, MenuActivity.class);
        intent.putExtra(EXTRA_VEHICULO, vehiculoRegistrado);

        // Pasar el nombre del administrador
        intent.putExtra(EXTRA_ADMIN, nombreAdministrador);

        startActivity(intent);
    }

    // ==========================
    //   MÉTODO DE LA API (VOLLEY)
    // ==========================
    // Versión "definitiva" ajustada a tu base de datos
    private void cargarDatos() {
        // Si quieres, podrías usar directamente URL_API aquí
        String url = URL_API;  // "https://leisurely-anthroposophic-shara.ngrok-free.dev/api_reparaciones.php";

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                url,
                null,
                response -> {
                    try {
                        // Si la lista tiene datos
                        if (response.length() > 0) {
                            // Tomamos el primer vehículo
                            JSONObject obj = response.getJSONObject(0);

                            // Leemos los datos EXACTOS de tu BD
                            String patente = obj.optString("patente", "Sin patente");
                            String marca = obj.optString("marca_auto", "Marca desconocida");
                            String orden = obj.optString("numero_orden", "0");

                            // Mostrar en pantalla
                            String mensaje = "¡CONECTADO!\nAuto: " + marca + " " + patente + "\nOrden #" + orden;
                            Toast.makeText(MainActivity.this, mensaje, Toast.LENGTH_LONG).show();

                            Log.d("API_EXITO", mensaje);
                        } else {
                            Toast.makeText(MainActivity.this, "Base de datos vacía", Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(MainActivity.this, "Error leyendo JSON: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    }
                },
                error -> {
                    Toast.makeText(MainActivity.this, "Error de Conexión: " + error.toString(), Toast.LENGTH_LONG).show();
                    Log.e("API_ERROR", error.toString());
                }
        ) {
            // --- ESTO ES OBLIGATORIO PARA NGROK GRATIS ---
            // Sin esto, la App recibe una página web de advertencia en vez del JSON y falla.
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("ngrok-skip-browser-warning", "true");
                return headers;
            }
        };

        queue.add(request);
    }
}
