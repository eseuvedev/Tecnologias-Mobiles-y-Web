package com.example.miautomotrizapp;
public class Servicio {

    // Atributos (Variables)
    private int id;
    private String nombre;
    private String descripcion;
    private String precio;
    private int imagen;

    // 🔑 NUEVOS ATRIBUTOS para la búsqueda
    private String patente;
    private String codigo;

    // Constructor existente (mantenido por compatibilidad)
    public Servicio(String nombre, String descripcion, String precio, int imagen) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.imagen = imagen;
        // Asumiendo valores por defecto si este constructor se usa para servicios genéricos
        this.patente = "";
        this.codigo = "";
    }

    // 🔑 NUEVO CONSTRUCTOR (Recomendado para Reparaciones específicas)
    public Servicio(String nombre, String descripcion, String precio, int imagen,
                    String patente, String codigo) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.imagen = imagen;
        this.patente = patente;
        this.codigo = codigo;
    }


    // Métodos para obtener (get) o establecer (set) el valor de los atributos

    // ... (Métodos existentes: getId, setId, getNombre, getDescripcion, getPrecio, getImagen) ...

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNombre() {
        return nombre;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public String getPrecio() {
        return precio;
    }
    public int getImagen() {
        return imagen;
    }

    // NUEVOS MÉTODOS GET
    public String getPatente() {
        return patente;
    }
    public String getCodigo() {
        return codigo;
    }

    // (Opcional, pero útil)
    public void setPatente(String patente) {
        this.patente = patente;
    }
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
}
