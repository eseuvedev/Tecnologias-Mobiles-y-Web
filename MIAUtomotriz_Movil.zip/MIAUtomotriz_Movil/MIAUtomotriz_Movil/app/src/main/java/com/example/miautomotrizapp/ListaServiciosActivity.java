package com.example.miautomotrizapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import com.example.miautomotrizapp.db.AutomotrizDbHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

public class ListaServiciosActivity extends AppCompatActivity {

    // --- Variables de clase ---
    private RecyclerView recyclerView;
    private ServicioAdapter adapter;
    private AutomotrizDbHelper dbHelper;
    private List<Servicio> listaServicios;

    // 🔍 NUEVA VARIABLE PARA EL BUSCADOR
    private EditText editTextSearch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_servicios);

        // --- Inicializar BD ---
        dbHelper = new AutomotrizDbHelper(this);

        // --- Configurar RecyclerView ---
        recyclerView = findViewById(R.id.recyclerServicios);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listaServicios = new ArrayList<>();
        adapter = new ServicioAdapter(this, listaServicios);
        recyclerView.setAdapter(adapter);

        // ============================
        //     🔍 BUSCADOR DE TEXTO
        // ============================
        editTextSearch = findViewById(R.id.editTextSearch);

        editTextSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                // Llama al método filter del adaptador
                adapter.filter(s.toString());
            }
        });

        // --- BOTÓN "+" ---
        FloatingActionButton fab = findViewById(R.id.fabAgregarServicio);
        fab.setOnClickListener(v -> {
            Intent intent = new Intent(ListaServiciosActivity.this, AgregarServicioActivity.class);
            startActivity(intent);
        });

        // Datos de prueba si la BD está vacía
        insertarDatosDePruebaSiVacio();
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarServiciosDesdeBD();
    }

    private void cargarServiciosDesdeBD() {
        List<Servicio> nuevaLista = dbHelper.leerTodosLosServicios();
        adapter.actualizarLista(nuevaLista);
    }

    private void insertarDatosDePruebaSiVacio() {
        if (dbHelper.leerTodosLosServicios().isEmpty()) {
            dbHelper.insertarServicio(new Servicio("Cambio de Aceite", "Incluye filtro y revisión general", "$25.000", R.drawable.aceite));
            dbHelper.insertarServicio(new Servicio("Alineación y Balanceo", "Optimiza el rendimiento de tus neumáticos", "$40.000", R.drawable.alineacion));
            dbHelper.insertarServicio(new Servicio("Lavado Integral", "Interior y exterior con productos premium", "$15.000", R.drawable.lavado));
            dbHelper.insertarServicio(new Servicio("Diagnóstico Computarizado", "Análisis completo de sistemas electrónicos", "$30.000", R.drawable.diagnostico));
        }
    }
}
