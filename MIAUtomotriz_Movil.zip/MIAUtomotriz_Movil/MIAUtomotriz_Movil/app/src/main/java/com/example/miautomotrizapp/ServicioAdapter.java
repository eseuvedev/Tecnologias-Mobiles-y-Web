package com.example.miautomotrizapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miautomotrizapp.db.AutomotrizDbHelper;

import java.util.ArrayList; // Importar ArrayList
import java.util.List;

public class ServicioAdapter extends RecyclerView.Adapter<ServicioAdapter.ServicioViewHolder> {

    private Context context;
    // Lista que se muestra actualmente
    private List<Servicio> listaServicios;
    // 🔑 LISTA COMPLETA (copia de la lista original)
    private List<Servicio> listaServiciosFull;
    private AutomotrizDbHelper dbHelper;

    public ServicioAdapter(Context context, List<Servicio> listaServicios) {
        this.context = context;
        this.listaServicios = listaServicios;
        // 🔑 Inicializar la lista completa con una copia de los datos originales
        this.listaServiciosFull = new ArrayList<>(listaServicios);
        this.dbHelper = new AutomotrizDbHelper(context);
    }

    @NonNull
    @Override
    public ServicioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_servicio, parent, false);
        return new ServicioViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ServicioViewHolder holder, int position) {
        Servicio servicio = listaServicios.get(position);

        holder.tvNombre.setText(servicio.getNombre());
        holder.tvDescripcion.setText(servicio.getDescripcion());
        holder.tvPrecio.setText(servicio.getPrecio());
        holder.ivIcono.setImageResource(servicio.getImagen());

        // La información de la patente o código se puede mostrar aquí si lo deseas:
        // holder.tvPatente.setText(servicio.getPatente());

        // [El resto de tu lógica para clics, editar, eliminar, se mantiene...]
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, EscogerMecanicoActivity.class);
            intent.putExtra("nombreServicio", servicio.getNombre());
            intent.putExtra("precioServicio", servicio.getPrecio());
            context.startActivity(intent);
        });

        // Accion de para el boton editar
        holder.ivEditar.setOnClickListener(v -> {
            // Obtenemos el ID del servicio
            int idServicioParaEditar = servicio.getId();

            // Creamos el Intent para abrir la pantalla de Edición
            Intent intent = new Intent(context, EditarServicioActivity.class);
            // Le pasamos el ID usando la constante que definimos
            intent.putExtra(EditarServicioActivity.EXTRA_SERVICIO_ID, idServicioParaEditar);

            context.startActivity(intent);
        });

        // ACCIÓN Dpara el boton eliminar
        holder.ivEliminar.setOnClickListener(v -> {
            int idServicioParaEliminar = servicio.getId();
            int currentPosition = holder.getAdapterPosition();

            if (currentPosition != RecyclerView.NO_POSITION) {
                int filasEliminadas = dbHelper.eliminarServicio(idServicioParaEliminar);
                if (filasEliminadas > 0) {
                    // Hay que eliminar de ambas listas
                    listaServicios.remove(currentPosition);
                    listaServiciosFull.remove(servicio); // Eliminar de la lista completa

                    notifyItemRemoved(currentPosition);
                    Toast.makeText(context, "Servicio eliminado", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Error al eliminar", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaServicios.size();
    }

    // Método para actualizar la lista (actualiza ambas listas)
    public void actualizarLista(List<Servicio> nuevaLista) {
        this.listaServiciosFull = new ArrayList<>(nuevaLista); // Reiniciar lista completa
        this.listaServicios.clear();
        this.listaServicios.addAll(nuevaLista);
        this.notifyDataSetChanged();
    }

    // 🔑 MÉTODO PRINCIPAL DE FILTRADO
    public void filter(String text) {
        // La lista filtrada se construirá aquí
        List<Servicio> filteredList = new ArrayList<>();
        // Convertir el texto de búsqueda a minúsculas
        String searchText = text.toLowerCase();

        if (searchText.isEmpty()) {
            // Si el texto está vacío, restaurar la lista original completa
            filteredList.addAll(listaServiciosFull);
        } else {
            // Recorrer la lista original completa para filtrar
            for (Servicio item : listaServiciosFull) {
                // Filtramos por patente O código
                if (item.getPatente().toLowerCase().contains(searchText) ||
                        item.getCodigo().toLowerCase().contains(searchText)) {

                    filteredList.add(item);
                }
            }
        }

        // 1. Reemplazar la lista actual con la filtrada
        listaServicios = filteredList;
        // 2. Notificar al RecyclerView que los datos han cambiado
        notifyDataSetChanged();
    }


    //ViewHolder
    public static class ServicioViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre, tvDescripcion, tvPrecio;
        ImageView ivIcono;
        ImageView ivEliminar;
        ImageView ivEditar;
        // Si quieres mostrar la patente/código, añádelo aquí
        // TextView tvPatente;

        public ServicioViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvNombreServicio);
            tvDescripcion = itemView.findViewById(R.id.tvDescripcionServicio);
            tvPrecio = itemView.findViewById(R.id.tvPrecioServicio);
            ivIcono = itemView.findViewById(R.id.ivIconoServicio);
            ivEliminar = itemView.findViewById(R.id.ivEliminarServicio);
            ivEditar = itemView.findViewById(R.id.ivEditarServicio);
            // tvPatente = itemView.findViewById(R.id.tvPatente);
        }
    }
}
