package com.example.miautomotrizapp;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    // Usamos la constante definida en LoginActivity
    public static final String EXTRA_ADMIN = "com.example.miautomotrizapp.EXTRA_ADMIN";
    public static final String EXTRA_VEHICULO = "com.miautomotriz.VEHICULO";

    private EditText etMatricula;
    private EditText etModelo;
    private Spinner spinnerTransmision;
    private Spinner spinnerCombustible;

    // Variable para el nombre del administrador
    private String nombreAdministrador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Recuperar el nombre del administrador desde el Intent
        if (getIntent().hasExtra(EXTRA_ADMIN)) {
            nombreAdministrador = getIntent().getStringExtra(EXTRA_ADMIN);
            Toast.makeText(this, "Bienvenido: " + nombreAdministrador, Toast.LENGTH_LONG).show();
        } else {
            nombreAdministrador = "Admin Desconocido";
        }

        // Inicializar las vistas
        etMatricula = findViewById(R.id.et_matricula);
        etModelo = findViewById(R.id.et_modelo);
        spinnerTransmision = findViewById(R.id.spinner_transmision);
        spinnerCombustible = findViewById(R.id.spinner_combustible);
    }

    /**
     * Método llamado al pulsar el botón "Registrar y Continuar".
     */
    public void registrarVehiculo(View view) {
        String matricula = etMatricula.getText().toString().trim();
        String modelo = etModelo.getText().toString().trim();
        String transmision = spinnerTransmision.getSelectedItem().toString();
        String combustible = spinnerCombustible.getSelectedItem().toString();

        if (matricula.isEmpty() || modelo.isEmpty() ||
                transmision.startsWith("Seleccionar") || combustible.startsWith("Seleccionar")) {
            Toast.makeText(this, "Por favor, completa todos los campos del vehículo.", Toast.LENGTH_LONG).show();
            return;
        }

        Vehiculo vehiculoRegistrado = new Vehiculo(matricula, modelo, transmision, combustible);

        // Crear Intent para ir a MenuActivity
        Intent intent = new Intent(this, MenuActivity.class);
        intent.putExtra(EXTRA_VEHICULO, vehiculoRegistrado);

        // Pasar el nombre del administrador
        intent.putExtra(EXTRA_ADMIN, nombreAdministrador);

        startActivity(intent);
    }
}
