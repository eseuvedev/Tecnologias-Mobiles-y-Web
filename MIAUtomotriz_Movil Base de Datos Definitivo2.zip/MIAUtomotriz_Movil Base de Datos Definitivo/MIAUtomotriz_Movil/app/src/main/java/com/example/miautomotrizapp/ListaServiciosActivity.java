package com.example.miautomotrizapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import com.example.miautomotrizapp.db.AutomotrizDbHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import android.content.Intent;
public class ListaServiciosActivity extends AppCompatActivity {

    //  2. Declarar variables a nivel de clase
    private RecyclerView recyclerView;
    private ServicioAdapter adapter;
    private AutomotrizDbHelper dbHelper;
    private List<Servicio> listaServicios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_servicios);

        //  3. Inicializar el DbHelper
        dbHelper = new AutomotrizDbHelper(this);

        //  4. Configurar RecyclerView
        recyclerView = findViewById(R.id.recyclerServicios);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 5. Inicializar el adaptador con una lista VACÍA
        listaServicios = new ArrayList<>();
        adapter = new ServicioAdapter(this, listaServicios);
        recyclerView.setAdapter(adapter);

        adapter = new ServicioAdapter(this, listaServicios);
        recyclerView.setAdapter(adapter);

        //  CÓDIGO PARA EL BOTÓN +
        FloatingActionButton fab = findViewById(R.id.fabAgregarServicio);
        fab.setOnClickListener(v -> {
            Intent intent = new Intent(ListaServiciosActivity.this, AgregarServicioActivity.class);
            startActivity(intent);
        });

        //(Solo para la presentacion) Insertar datos de prueba SOLO la primera vez
        insertarDatosDePruebaSiVacio();
    }

    /**
     * Implementación del Ciclo de Vida
     * Este método se llama CADA VEZ que la pantalla se vuelve visible
     */
    @Override
    protected void onResume() {
        super.onResume();
        // Llamamos a nuestro método para cargar/refrescar los datos
        cargarServiciosDesdeBD();
    }

    /**
     *  Método HELPER para cargar datos de la base de datos
     */
    private void cargarServiciosDesdeBD() {
        List<Servicio> nuevaLista = dbHelper.leerTodosLosServicios();

        adapter.actualizarLista(nuevaLista);
    }


    /**
     * Inserta los datos de ejemplo si la base de datos está vacía (eliminar despues de la entrega)
     */
    private void insertarDatosDePruebaSiVacio() {
        // Comprueba si la BD ya tiene datos
        if (dbHelper.leerTodosLosServicios().isEmpty()) {

            dbHelper.insertarServicio(new Servicio("Cambio de Aceite", "Incluye filtro y revisión general", "$25.000", R.drawable.aceite));
            dbHelper.insertarServicio(new Servicio("Alineación y Balanceo", "Optimiza el rendimiento de tus neumáticos", "$40.000", R.drawable.alineacion));
            dbHelper.insertarServicio(new Servicio("Lavado Integral", "Interior y exterior con productos premium", "$15.000", R.drawable.lavado));
            dbHelper.insertarServicio(new Servicio("Diagnóstico Computarizado", "Análisis completo de sistemas electrónicos", "$30.000", R.drawable.diagnostico));
        }
    }
}
