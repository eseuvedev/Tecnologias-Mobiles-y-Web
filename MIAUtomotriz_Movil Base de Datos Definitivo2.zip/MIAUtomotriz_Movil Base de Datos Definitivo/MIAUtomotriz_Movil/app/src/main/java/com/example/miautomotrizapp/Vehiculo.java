package com.example.miautomotrizapp;
// app/src/main/java/.../Vehiculo.java
import androidx.annotation.NonNull;

import java.io.Serializable;

public class Vehiculo implements Serializable {
    private String matricula;
    private String modelo;
    private String transmision;
    private String combustible;

    // Constructor
    public Vehiculo(String matricula, String modelo, String transmision, String combustible) {
        this.matricula = matricula;
        this.modelo = modelo;
        this.transmision = transmision;
        this.combustible = combustible;
    }

    // Getters (solo se incluyen los Getters para simplificar)
    public String getMatricula() {
        return matricula;
    }

    public String getModelo() {
        return modelo;
    }

    public String getTransmision() {
        return transmision;
    }

    public String getCombustible() {
        return combustible;
    }

    // Método toString (útil para debug o mostrar resumen)
    @NonNull
    @Override
    public String toString() {
        return "Auto registrado: Matrícula=" + matricula + ", Modelo=" + modelo;
    }
}