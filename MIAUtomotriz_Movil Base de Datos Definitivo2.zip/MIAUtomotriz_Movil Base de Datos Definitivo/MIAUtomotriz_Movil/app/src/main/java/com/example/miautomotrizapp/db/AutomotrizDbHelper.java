package com.example.miautomotrizapp.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

import com.example.miautomotrizapp.Servicio; // Importamos tu clase Modelo

// Es la clase principal que controla toda la base de datos
public class AutomotrizDbHelper extends SQLiteOpenHelper {

    // Constantes Generales
    // Define la versión y nombre del archivo de la BD
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "automotriz.db";

    // Define el nombre de la tabla y sus columnas
    public static final String TABLE_SERVICIOS = "servicios";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NOMBRE = "nombre";
    public static final String COLUMN_DESCRIPCION = "descripcion";
    public static final String COLUMN_PRECIO = "precio";
    public static final String COLUMN_IMAGEN = "imagen";

    // Constructor (necesario para inicializar el Helper)
    public AutomotrizDbHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Se ejecuta 1 sola vez para CREAR la estructura (la tabla)
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_SERVICIOS = "CREATE TABLE " + TABLE_SERVICIOS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NOMBRE + " TEXT,"
                + COLUMN_DESCRIPCION + " TEXT,"
                + COLUMN_PRECIO + " TEXT,"
                + COLUMN_IMAGEN + " INTEGER" + ")";

        db.execSQL(CREATE_TABLE_SERVICIOS);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SERVICIOS);
        onCreate(db);
    }

    //Métodos CRUD

    public long insertarServicio(Servicio servicio) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(COLUMN_NOMBRE, servicio.getNombre());
        values.put(COLUMN_DESCRIPCION, servicio.getDescripcion());
        values.put(COLUMN_PRECIO, servicio.getPrecio());
        values.put(COLUMN_IMAGEN, servicio.getImagen());

        long newRowId = db.insert(TABLE_SERVICIOS, null, values);
        db.close();
        return newRowId;
    }

    // Lee TODOS los servicios de la base de datos
    public List<Servicio> leerTodosLosServicios() {
        List<Servicio> listaServicios = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_SERVICIOS, null, null, null, null, null, null);

        int idIndex = cursor.getColumnIndex(COLUMN_ID);
        int nombreIndex = cursor.getColumnIndex(COLUMN_NOMBRE);

        while (cursor.moveToNext()) {
            if (idIndex != -1 && nombreIndex != -1 /* ...etc */) {
                Servicio servicio = new Servicio(nombre, descripcion, precio, imagen);
                servicio.setId(id);
                listaServicios.add(servicio);
            }
        }
        cursor.close();
        db.close();
        return listaServicios;
    }

    public int actualizarServicio(Servicio servicio) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        // Define qué fila actualizar basado en el ID
        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(servicio.getId()) };

        int count = db.update(
                TABLE_SERVICIOS,
                values,
                selection,
                selectionArgs);
        db.close();
        return count;
    }

    public int eliminarServicio(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Define qué fila borrar basado en el ID
        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        int deletedRows = db.delete(TABLE_SERVICIOS, selection, selectionArgs);
        db.close();
        return deletedRows;
    }

    public Servicio leerServicioPorId(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {
                COLUMN_ID, COLUMN_NOMBRE, COLUMN_DESCRIPCION,
                COLUMN_PRECIO, COLUMN_IMAGEN
        };

        // Define qué fila leer basado en el ID
        String selection = COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(id) };

        Cursor cursor = db.query(
                TABLE_SERVICIOS,
                projection,
                selection,
                selectionArgs,
                null, null, null
        );

        Servicio servicio = null;

        // Si encontramos un resultado, lo leemos
        if (cursor.moveToFirst()) {
            servicio = new Servicio(nombre, descripcion, precio, imagen);
            servicio.setId(id);
            Changelog
        }
        cursor.close();
        db.close();
        return servicio;
    }
}