package com.example.miautomotrizapp;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.view.View;

public class MenuActivity extends AppCompatActivity {

    private Button btnConfirmarDatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button btnServicios = findViewById(R.id.btnServicios);
        btnServicios.setOnClickListener(v -> {
            Intent intent = new Intent(MenuActivity.this, ListaServiciosActivity.class);
            startActivity(intent);
        });

        // Obtiene el nombre del administrador
        String adminNombre = getIntent().getStringExtra(MainActivity.EXTRA_ADMIN);

        // Intentamos recuperar el objeto Vehiculo
        if (getIntent().hasExtra(MainActivity.EXTRA_VEHICULO)) {
            Vehiculo vehiculo = (Vehiculo) getIntent().getSerializableExtra(MainActivity.EXTRA_VEHICULO);

            if (vehiculo != null) {
                // Crear el resumen con ambos datos
                TextView tvDatos = findViewById(R.id.tv_datos_vehiculo);
                String resumen = "¡Bienvenido, " + adminNombre + "!\n\n" + // Nombre del administrador
                        "Registro de Vehículo Completado:\n" +
                        "Matrícula: " + vehiculo.getMatricula() + "\n" +
                        "Modelo: " + vehiculo.getModelo() + "\n" +
                        "Transmisión: " + vehiculo.getTransmision() + "\n" +
                        "Combustible: " + vehiculo.getCombustible() + "\n\n";
                tvDatos.setText(resumen);

                Toast.makeText(this, "Registro exitoso por " + adminNombre, Toast.LENGTH_LONG).show();
            }
        } else {
            Toast.makeText(MenuActivity.this, "Error: Faltan datos de vehículo o administrador.", Toast.LENGTH_LONG).show();
        }
    }
}