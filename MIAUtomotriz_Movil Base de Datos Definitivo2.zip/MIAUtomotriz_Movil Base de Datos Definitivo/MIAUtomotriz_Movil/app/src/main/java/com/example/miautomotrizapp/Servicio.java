package com.example.miautomotrizapp;

public class Servicio {

    // Atributos (Variables)
    private int id;
    private String nombre;
    private String descripcion;
    private String precio;
    private int imagen;

    //Lo siguiente se usa para crear una nueva instancia de Servicio
    public Servicio(String nombre, String descripcion, String precio, int imagen) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.precio = precio;
        this.imagen = imagen;
    }

    // Métodos para obtener (get) o establecer (set) el valor de los atributos
    // Devuelve el ID
    public int getId() {
        return id;
    }
    // Establece el ID
    public void setId(int id) {
        this.id = id;
    }
    // Devuelve el Nombre
    public String getNombre() {
        return nombre;
    }
    // Devuelve la Descripción
    public String getDescripcion() {
        return descripcion;
    }
    // Devuelve el Precio
    public String getPrecio() {
        return precio;
    }
    // Devuelve el ID de la imagen
    public int getImagen() {
        return imagen;
    }
}